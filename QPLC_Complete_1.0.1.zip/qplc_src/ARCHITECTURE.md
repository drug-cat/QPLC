# QPLC architecture 1.0

## Compilation pipeline

```text
.q source
   │
   ▼
Lexer ──► tokens + source locations
   │
   ▼
Recursive-descent Parser
   │
   ▼
AST
   │
   ▼
Semantic Analyzer ──► typed validation + diagnostics
   │
   ▼
Ladder-oriented runtime XML
   │
   ├────────► Visual Simulator
   ├────────► Text Simulator
   └────────► Siemens/TIA export boundary
```

## Deterministic runtime model

A generated rung is an executable runtime instruction. The simulator indexes labels and executes a program counter instead of treating networks as passive drawings. This makes `JMP/JMPN/LABEL` meaningful and allows `while` loops to be tested under an instruction watchdog.

Stateful runtime objects are keyed by their output symbol:

- timers — TON/TOF/TP state
- counters — edge memory + current value + preset
- edge detectors — previous input state
- latches — current output state
- force table — external test override state

## Memory model

The compiler keeps symbolic names in the generated XML where possible. Array elements are lowered to physical Siemens-style addresses when the index is a compile-time integer (including expressions such as `i + 1` after `for` unrolling).

The configuration distinguishes:

- `I...` — inputs
- `Q...` — outputs
- `M...` under `[memory]` — internal memory
- `retain` — non-volatile/retentive simulation state marker

## Industrialization boundary

The current backend is intentionally not a real Siemens machine-code/MC7 generator. The XML is a stable intermediate/runtime format. A future typed IR should sit between semantic analysis and target backends when adding:

- FB/FC interfaces
- structures/enums/UDTs
- exact IEC integer widths and overflow policy
- explicit memory allocation
- S7-1200/S7-1500 instruction selection
- source maps for online diagnostics
- versioned TIA Openness project generation
