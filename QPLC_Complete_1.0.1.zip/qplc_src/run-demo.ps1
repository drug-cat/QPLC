$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
cmake --build (Join-Path $root 'build') --config Release
$compiler = Join-Path $root 'build\Release\qplc.exe'
if (!(Test-Path $compiler)) { $compiler = Join-Path $root 'build\qplc.exe' }
$conf = Join-Path $root 'examples\conf.qplc'
$program = Join-Path $root 'examples\test_all.q'
$output = Join-Path $root 'output.xml'
& $compiler $conf $program -o $output
if ($LASTEXITCODE -ne 0) { throw 'QPLC compilation failed.' }
if (Get-Command dotnet -ErrorAction SilentlyContinue) {
  dotnet run --project (Join-Path $root 'QPLCVisualSimulator\QPLCVisualSimulator.csproj')
} else { Write-Warning 'dotnet SDK is not installed. Generated output.xml is ready for the simulator.' }
