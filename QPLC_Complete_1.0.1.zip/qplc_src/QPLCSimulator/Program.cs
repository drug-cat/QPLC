using System;
using System.Globalization;
using System.Linq;

namespace QPLCSimulator;

internal static class Program
{
    public static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("QPLC Simulator 1.0");
            Console.WriteLine("Usage: QPLCSimulator <config.qplc> <ladder.xml>");
            return;
        }
        var config = ConfigParser.Parse(args[0]);
        var networks = LadderXmlParser.Parse(args[1]);
        var sim = new LadderSimulator(networks, config);
        Console.WriteLine($"QPLC Simulator 1.0 | CPU={config.Hardware.Cpu} | Cycle={config.Runtime.CycleMs} ms | Watchdog={config.Runtime.WatchdogMs} ms");
        Console.WriteLine("Commands: set <tag> <value>, force <tag> <value>, release <tag>, tick <ms>, run, show, trace, reset, exit");
        while (true)
        {
            Console.Write("qplc> ");
            var line = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(line)) continue;
            var p = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            try
            {
                switch (p[0].ToLowerInvariant())
                {
                    case "set": Set(sim, p, false); break;
                    case "force": Set(sim, p, true); break;
                    case "release": sim.ReleaseForce(p[1]); break;
                    case "tick": sim.AdvanceTime(double.Parse(p[1], CultureInfo.InvariantCulture)); break;
                    case "run": sim.RunScan(); Console.WriteLine($"scan={sim.ScanCount} instructions={sim.LastInstructions} watchdog={sim.WatchdogTripped}"); break;
                    case "show": Show(sim); break;
                    case "trace": foreach (var e in sim.Trace.TakeLast(50)) Console.WriteLine($"{e.Scan}:{e.Instruction} {e.Network} power={e.PowerFlow} {e.Action}"); break;
                    case "reset": sim.Reset(); break;
                    case "exit": return;
                    default: Console.WriteLine("Unknown command"); break;
                }
            }
            catch (Exception ex) { Console.WriteLine($"error: {ex.Message}"); }
        }
    }

    private static void Set(LadderSimulator sim, string[] p, bool force)
    {
        if (p.Length < 3) throw new ArgumentException("set/force <tag> <value>");
        if (bool.TryParse(p[2], out var b)) { if (force) sim.ForceBool(p[1], b); else sim.SetBool(p[1], b); return; }
        if (double.TryParse(p[2], NumberStyles.Float, CultureInfo.InvariantCulture, out var n)) { if (force) sim.ForceNumeric(p[1], n); else sim.SetNumeric(p[1], n); return; }
        throw new ArgumentException("invalid value");
    }

    private static void Show(LadderSimulator sim)
    {
        foreach (var t in sim.GetTags()) Console.WriteLine($"{t.Name,-24} {t.Address,-10} {(t.Type == "BOOL" ? (t.BoolValue == true ? "TRUE" : "FALSE") : t.NumericValue?.ToString("0.###", CultureInfo.InvariantCulture)), -10} {(t.Forced ? "FORCED" : "")}");
        Console.WriteLine($"scan={sim.ScanCount} time={sim.CurrentTime:0.###} ms instructions={sim.LastInstructions} watchdog={sim.WatchdogTripped}");
    }
}
