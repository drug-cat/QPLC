using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace QPLCVisualSimulator;

public enum VariableKind { Input, Output, Memory }

public sealed class IoMapping
{
    public string Address { get; init; } = "";
    public string Type { get; init; } = "";
    public int ArrayLength { get; init; } = 1;
    public bool Retain { get; init; }
    public VariableKind Kind { get; init; } = VariableKind.Memory;
    public bool IsArray => ArrayLength > 1;
}

public sealed class HardwareConfig { public string Cpu { get; set; } = ""; public string Ip { get; set; } = ""; }
public sealed class RuntimeConfig
{
    public double CycleMs { get; set; } = 10;
    public double WatchdogMs { get; set; } = 100;
    public long MaxInstructions { get; set; } = 100_000;
    public bool RetainMemory { get; set; } = true;
    public bool ResetOutputsOnStartup { get; set; } = true;
}
public sealed class Config
{
    public HardwareConfig Hardware { get; set; } = new();
    public RuntimeConfig Runtime { get; set; } = new();
    public Dictionary<string, IoMapping> Io { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}

public static class ConfigParser
{
    public static Config Parse(string filePath)
    {
        if (!File.Exists(filePath)) throw new FileNotFoundException("QPLC configuration not found", filePath);
        var c = new Config();
        string section = "";
        int lineNo = 0;
        foreach (var raw in File.ReadLines(filePath))
        {
            lineNo++;
            var line = raw.Trim();
            if (line.Length == 0 || line.StartsWith('#')) continue;
            if (line.StartsWith('[') && line.EndsWith(']')) { section = line[1..^1].Trim(); continue; }
            int eq = line.IndexOf('=');
            if (eq < 0) throw new InvalidDataException($"conf.qplc line {lineNo}: expected '='");
            string key = line[..eq].Trim(), value = line[(eq + 1)..].Trim();
            if (section.Equals("hardware", StringComparison.OrdinalIgnoreCase))
            {
                if (key.Equals("cpu", StringComparison.OrdinalIgnoreCase)) c.Hardware.Cpu = value;
                else if (key.Equals("ip", StringComparison.OrdinalIgnoreCase)) c.Hardware.Ip = value;
                continue;
            }
            if (section.Equals("runtime", StringComparison.OrdinalIgnoreCase))
            {
                if (key.Equals("cycle_ms", StringComparison.OrdinalIgnoreCase)) c.Runtime.CycleMs = ParseDouble(value, lineNo);
                else if (key.Equals("watchdog_ms", StringComparison.OrdinalIgnoreCase)) c.Runtime.WatchdogMs = ParseDouble(value, lineNo);
                else if (key.Equals("max_instructions", StringComparison.OrdinalIgnoreCase)) c.Runtime.MaxInstructions = long.Parse(value, CultureInfo.InvariantCulture);
                else if (key.Equals("retain_memory", StringComparison.OrdinalIgnoreCase)) c.Runtime.RetainMemory = ParseBool(value, lineNo);
                else if (key.Equals("reset_outputs_on_startup", StringComparison.OrdinalIgnoreCase)) c.Runtime.ResetOutputsOnStartup = ParseBool(value, lineNo);
                continue;
            }
            if (!section.Equals("io", StringComparison.OrdinalIgnoreCase) && !section.Equals("memory", StringComparison.OrdinalIgnoreCase)) continue;
            int colon = value.LastIndexOf(':');
            if (colon <= 0) throw new InvalidDataException($"conf.qplc line {lineNo}: invalid mapping");
            string address = value[..colon].Trim();
            string typePart = value[(colon + 1)..].Trim();
            bool retain = false;
            int comma = typePart.IndexOf(',');
            if (comma >= 0)
            {
                var attrs = typePart[(comma + 1)..].Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                foreach (var attr in attrs)
                {
                    if (attr.Equals("retain", StringComparison.OrdinalIgnoreCase) || attr.Equals("retentive", StringComparison.OrdinalIgnoreCase)) retain = true;
                    else throw new InvalidDataException($"conf.qplc line {lineNo}: unknown mapping attribute '{attr}'");
                }
                typePart = typePart[..comma].Trim();
            }
            int length = 1;
            int open = typePart.IndexOf('[');
            if (open >= 0)
            {
                if (!typePart.EndsWith(']')) throw new InvalidDataException($"conf.qplc line {lineNo}: invalid array declaration");
                length = int.Parse(typePart[(open + 1)..^1], CultureInfo.InvariantCulture);
                typePart = typePart[..open].Trim();
            }
            if (length < 1) throw new InvalidDataException($"conf.qplc line {lineNo}: invalid array length");
            string type = typePart.ToUpperInvariant();
            if (type is not ("BOOL" or "INT" or "DINT" or "REAL" or "TIME")) throw new InvalidDataException($"conf.qplc line {lineNo}: unsupported type '{type}'");
            var kind = section.Equals("memory", StringComparison.OrdinalIgnoreCase)
                ? VariableKind.Memory
                : address.StartsWith("I", StringComparison.OrdinalIgnoreCase) ? VariableKind.Input
                : address.StartsWith("Q", StringComparison.OrdinalIgnoreCase) ? VariableKind.Output
                : VariableKind.Memory;
            if (c.Io.ContainsKey(key)) throw new InvalidDataException($"conf.qplc line {lineNo}: duplicate variable '{key}'");
            c.Io[key] = new IoMapping { Address = address, Type = type, ArrayLength = length, Retain = retain, Kind = kind };
        }
        if (string.IsNullOrWhiteSpace(c.Hardware.Cpu) || string.IsNullOrWhiteSpace(c.Hardware.Ip)) throw new InvalidDataException("conf.qplc requires [hardware] cpu and ip");
        if (c.Io.Count == 0) throw new InvalidDataException("conf.qplc has no variables");
        return c;
    }

    private static double ParseDouble(string value, int line) => double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d : throw new InvalidDataException($"conf.qplc line {line}: invalid number '{value}'");
    private static bool ParseBool(string value, int line)
    {
        if (bool.TryParse(value, out var b)) return b;
        if (value is "1" or "yes" or "on") return true;
        if (value is "0" or "no" or "off") return false;
        throw new InvalidDataException($"conf.qplc line {line}: invalid boolean '{value}'");
    }
}
