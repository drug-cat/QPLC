using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Xml.Linq;

namespace QPLCVisualSimulator;

public class LadderElement
{
    public string Type { get; set; } = "";
    public string Address { get; set; } = "";
    public string ContactType { get; set; } = "";
    public string Op { get; set; } = "";
    public string Left { get; set; } = "";
    public string Right { get; set; } = "";
    public string Label { get; set; } = "";
    public string JumpType { get; set; } = "";
    public string Dest { get; set; } = "";
    public string Source { get; set; } = "";
    public string Input1 { get; set; } = "";
    public string Input2 { get; set; } = "";
    public string Input3 { get; set; } = "";
    public string Input4 { get; set; } = "";
    public string Preset { get; set; } = "";
    public string Duration { get; set; } = "";
    public string EdgeType { get; set; } = "";
    public string LatchType { get; set; } = "";
    public string SetExpr { get; set; } = "";
    public string ResetExpr { get; set; } = "";
}

public class LadderRung
{
    public List<List<LadderElement>> Branches { get; set; } = new();
    public LadderElement? Coil { get; set; }
    public LadderElement? Move { get; set; }
    public LadderElement? Jump { get; set; }
    public LadderElement? Label { get; set; }
    public LadderElement? Timer { get; set; }
    public LadderElement? Counter { get; set; }
    public LadderElement? Edge { get; set; }
    public LadderElement? Latch { get; set; }
}

public class LadderNetwork
{
    public string Name { get; set; } = "";
    public List<LadderRung> Rungs { get; set; } = new();
}

public static class LadderXmlParser
{
    public static List<LadderNetwork> Parse(string filePath) => ParseDocument(XDocument.Load(filePath));
    public static List<LadderNetwork> ParseXml(string xml) => ParseDocument(XDocument.Parse(xml));

    private static List<LadderNetwork> ParseDocument(XDocument doc)
    {
        var result = new List<LadderNetwork>();
        foreach (var networkElem in doc.Descendants("network"))
        {
            var network = new LadderNetwork { Name = (string?)networkElem.Attribute("name") ?? "" };
            foreach (var rungElem in networkElem.Elements("rung"))
            {
                var rung = new LadderRung();
                foreach (var branchElem in rungElem.Elements("branch"))
                {
                    var branch = new List<LadderElement>();
                    foreach (var elem in branchElem.Elements()) branch.Add(ParseElement(elem));
                    rung.Branches.Add(branch);
                }
                if (rungElem.Element("coil") is { } coil) rung.Coil = ParseElement(coil);
                if (rungElem.Element("move") is { } move) rung.Move = ParseElement(move);
                if (rungElem.Element("jump") is { } jump) rung.Jump = ParseElement(jump);
                if (rungElem.Element("label") is { } label) rung.Label = ParseElement(label);
                if (rungElem.Element("timer") is { } timer) rung.Timer = ParseElement(timer);
                if (rungElem.Element("counter") is { } counter) rung.Counter = ParseElement(counter);
                if (rungElem.Element("edge") is { } edge) rung.Edge = ParseElement(edge);
                if (rungElem.Element("latch") is { } latch) rung.Latch = ParseElement(latch);
                network.Rungs.Add(rung);
            }
            result.Add(network);
        }
        return result;
    }

    private static LadderElement ParseElement(XElement e)
    {
        var x = new LadderElement { Type = e.Name.LocalName };
        x.Address = (string?)e.Attribute("address") ?? (string?)e.Attribute("output") ?? "";
        x.ContactType = (string?)e.Attribute("type") ?? "";
        x.Op = (string?)e.Attribute("op") ?? "";
        x.Left = (string?)e.Attribute("left") ?? "";
        x.Right = (string?)e.Attribute("right") ?? "";
        x.Label = (string?)e.Attribute("label") ?? (string?)e.Attribute("name") ?? "";
        x.JumpType = (string?)e.Attribute("type") ?? "jmp";
        x.Dest = (string?)e.Attribute("dest") ?? "";
        x.Source = (string?)e.Attribute("source") ?? "";
        x.Input1 = (string?)e.Attribute("input") ?? (string?)e.Attribute("up") ?? "";
        x.Input2 = (string?)e.Attribute("reset") ?? (string?)e.Attribute("down") ?? (string?)e.Attribute("set") ?? "";
        x.Input3 = (string?)e.Attribute("down") ?? (string?)e.Attribute("reset") ?? "";
        x.Input4 = (string?)e.Attribute("load") ?? (string?)e.Attribute("reset") ?? "";
        x.Preset = (string?)e.Attribute("preset") ?? "";
        x.Duration = (string?)e.Attribute("duration") ?? "";
        x.EdgeType = (string?)e.Attribute("type") ?? "";
        x.LatchType = (string?)e.Attribute("type") ?? "";
        x.SetExpr = (string?)e.Attribute("set") ?? "";
        x.ResetExpr = (string?)e.Attribute("reset") ?? "";
        return x;
    }
}
