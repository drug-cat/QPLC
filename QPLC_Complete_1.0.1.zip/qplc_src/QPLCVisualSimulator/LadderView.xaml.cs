using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace QPLCVisualSimulator;

public partial class LadderView : UserControl
{
    private const double LeftRail = 42, RightRail = 1280, ElementW = 82, Gap = 12, ContactH = 32;
    private List<LadderNetwork> networks = new();
    private LadderSimulator? simulator;
    private readonly Brush Active = new SolidColorBrush(Color.FromRgb(22, 163, 74));
    private readonly Brush Inactive = new SolidColorBrush(Color.FromRgb(148, 163, 184));
    private readonly Brush Rail = new SolidColorBrush(Color.FromRgb(30, 41, 59));
    private readonly Brush Text = new SolidColorBrush(Color.FromRgb(15, 23, 42));

    public LadderView() => InitializeComponent();
    public void SetSimulator(LadderSimulator sim) => simulator = sim;

    public void DrawNetworks(List<LadderNetwork> nets)
    {
        networks = nets;
        LadderCanvas.Children.Clear();
        double y = 16;
        foreach (var network in networks)
        {
            AddText(network.Name, LeftRail, y, 14, FontWeights.Bold, new SolidColorBrush(Color.FromRgb(37,99,235)));
            y += 28;
            foreach (var rung in network.Rungs)
            {
                double h = Math.Max(64, rung.Branches.Count * 46 + 20);
                DrawRung(rung, y, h);
                y += h + 18;
            }
            y += 14;
        }
        LadderCanvas.Width = RightRail + 100;
        LadderCanvas.Height = Math.Max(y + 20, 300);
    }

    private void DrawRung(LadderRung rung, double y, double h)
    {
        double center = y + h / 2;
        AddLine(LeftRail, y, LeftRail, y + h, Rail, 4);
        AddLine(RightRail, y, RightRail, y + h, Rail, 4);
        bool power = EvaluateRung(rung);
        double outputW = rung.Counter != null ? 150 : rung.Latch != null ? 150 : rung.Timer != null ? 130 : rung.Edge != null ? 130 : rung.Coil != null ? 100 : rung.Move != null ? 120 : 110;
        double outputX = RightRail - outputW - 20;

        if (rung.Branches.Count <= 1)
        {
            var branch = rung.Branches.FirstOrDefault() ?? new List<LadderElement>();
            DrawBranch(branch, center, LeftRail + 18, outputX, power);
        }
        else
        {
            double spacing = h / (rung.Branches.Count + 1);
            double commonX = LeftRail + 18;
            double endX = outputX;
            for (int i = 0; i < rung.Branches.Count; i++)
            {
                double by = y + spacing * (i + 1);
                bool active = EvaluateBranch(rung.Branches[i]);
                AddLine(commonX, center, commonX, by, active ? Active : Inactive, 2);
                DrawBranch(rung.Branches[i], by, commonX, endX, active);
                AddLine(endX, by, endX, center, active ? Active : Inactive, 2);
            }
            AddLine(commonX, center, endX, center, power ? Active : Inactive, 2);
        }

        if (rung.Coil != null) DrawCoil(rung.Coil, outputX, center, power);
        else if (rung.Timer != null) DrawTimer(rung.Timer, outputX, center, power);
        else if (rung.Counter != null) DrawCounter(rung.Counter, outputX, center, power);
        else if (rung.Edge != null) DrawEdge(rung.Edge, outputX, center, power);
        else if (rung.Latch != null) DrawLatch(rung.Latch, outputX, center, power);
        else if (rung.Move != null) DrawMove(rung.Move, outputX, center, power);
        else if (rung.Jump != null) AddText($"{rung.Jump.JumpType.ToUpperInvariant()} → {rung.Jump.Label}", outputX, center - 10, 11, FontWeights.Bold, Text);
        AddLine(outputX + outputW, center, RightRail, center, power ? Active : Inactive, 2);
    }

    private void DrawBranch(List<LadderElement> branch, double y, double start, double end, bool power)
    {
        double x = start;
        AddLine(LeftRail, y, start, y, power ? Active : Inactive, 2);
        foreach (var e in branch)
        {
            if (e.Type == "contact") { DrawContact(e, x, y, EvaluateElement(e)); x += ElementW; }
            else if (e.Type == "comparison") { DrawComparison(e, x, y, EvaluateElement(e)); x += ElementW; }
            AddLine(x - Gap, y, x, y, power ? Active : Inactive, 2);
            x += Gap;
            if (x > end - 30) break;
        }
        AddLine(Math.Min(x, end), y, end, y, power ? Active : Inactive, 2);
    }

    private void DrawContact(LadderElement e, double x, double y, bool active)
    {
        var b = active ? Active : Inactive;
        AddLine(x + 12, y - ContactH/2, x + 12, y + ContactH/2, b, 2.5);
        AddLine(x + 28, y - ContactH/2, x + 28, y + ContactH/2, b, 2.5);
        if (e.ContactType.Equals("NC", StringComparison.OrdinalIgnoreCase)) AddLine(x + 8, y + ContactH/2, x + 32, y - ContactH/2, b, 2);
        AddText(e.Address, x, y + ContactH/2 + 2, 9, FontWeights.Normal, Text);
        var hit = new Rectangle { Width = 48, Height = 50, Fill = Brushes.Transparent, Cursor = Cursors.Hand, ToolTip = $"Toggle {e.Address}" };
        hit.MouseLeftButtonDown += (_, _) => ToggleContact(e.Address);
        Canvas.SetLeft(hit, x); Canvas.SetTop(hit, y - 25); LadderCanvas.Children.Add(hit);
    }

    private void DrawComparison(LadderElement e, double x, double y, bool active)
    {
        var r = new Border { Width = 72, Height = 34, Background = Brushes.White, BorderBrush = active ? Active : Inactive, BorderThickness = new Thickness(2), CornerRadius = new CornerRadius(4), Child = new TextBlock { Text = $"{e.Left}\n{OpText(e.Op)} {e.Right}", FontSize = 8, Foreground = Text, TextAlignment = TextAlignment.Center } };
        Canvas.SetLeft(r, x); Canvas.SetTop(r, y - 17); LadderCanvas.Children.Add(r);
    }

    private void DrawCoil(LadderElement e, double x, double y, bool power)
    {
        string symbol = e.ContactType.Equals("reset", StringComparison.OrdinalIgnoreCase) ? "(R)" : e.ContactType.Equals("set", StringComparison.OrdinalIgnoreCase) ? "(S)" : "( )";
        AddText($"{symbol}  {e.Address}", x, y - 10, 12, FontWeights.Bold, power ? Active : Text);
    }
    private void DrawTimer(LadderElement e, double x, double y, bool power)
    {
        var box = new Border { Width = 120, Height = 54, Background = Brushes.White, BorderBrush = power ? Active : Inactive, BorderThickness = new Thickness(2), CornerRadius = new CornerRadius(5) };
        var stack = new StackPanel(); stack.Children.Add(new TextBlock { Text = e.ContactType.ToUpperInvariant(), FontWeight = FontWeights.Bold, Foreground = Text, HorizontalAlignment = HorizontalAlignment.Center }); stack.Children.Add(new TextBlock { Text = $"Q: {e.Address}\nPT: {e.Source}", FontSize = 9, Foreground = Text, TextAlignment = TextAlignment.Center }); box.Child = stack;
        Canvas.SetLeft(box, x); Canvas.SetTop(box, y - 27); LadderCanvas.Children.Add(box);
    }
    private void DrawCounter(LadderElement e, double x, double y, bool power)
    {
        int count = simulator?.Counters.TryGetValue(e.Address, out var c) == true ? c.Count : 0;
        var box = new Border { Width = 140, Height = 60, Background = Brushes.White, BorderBrush = power ? Active : Inactive, BorderThickness = new Thickness(2), CornerRadius = new CornerRadius(5) };
        box.Child = new TextBlock { Text = $"{e.ContactType.ToUpperInvariant()}\n{e.Address}\nCV={count} / PV={e.Preset}", FontSize = 9, Foreground = Text, TextAlignment = TextAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        Canvas.SetLeft(box, x); Canvas.SetTop(box, y - 30); LadderCanvas.Children.Add(box);
    }

    private void DrawEdge(LadderElement e, double x, double y, bool power)
    {
        var box = new Border { Width = 120, Height = 46, Background = Brushes.White, BorderBrush = power ? Active : Inactive, BorderThickness = new Thickness(2), CornerRadius = new CornerRadius(5) };
        box.Child = new TextBlock { Text = $"{e.EdgeType.ToUpperInvariant()} EDGE\nIN: {e.Input1}\nQ: {e.Address}", FontSize = 9, Foreground = Text, TextAlignment = TextAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        Canvas.SetLeft(box, x); Canvas.SetTop(box, y - 23); LadderCanvas.Children.Add(box);
    }
    private void DrawLatch(LadderElement e, double x, double y, bool power)
    {
        var box = new Border { Width = 140, Height = 50, Background = Brushes.White, BorderBrush = power ? Active : Inactive, BorderThickness = new Thickness(2), CornerRadius = new CornerRadius(5) };
        box.Child = new TextBlock { Text = $"{e.LatchType} LATCH\nS: {e.SetExpr}\nR: {e.ResetExpr}", FontSize = 8, Foreground = Text, TextAlignment = TextAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        Canvas.SetLeft(box, x); Canvas.SetTop(box, y - 25); LadderCanvas.Children.Add(box);
    }

    private void DrawMove(LadderElement e, double x, double y, bool power) => AddText($"MOVE\n{e.Source} → {e.Dest}", x, y - 18, 10, FontWeights.Bold, power ? Active : Text);

    private bool EvaluateRung(LadderRung r) => r.Branches.Count == 0 || r.Branches.Any(EvaluateBranch);
    private bool EvaluateBranch(List<LadderElement> b) => b.All(EvaluateElement);
    private bool EvaluateElement(LadderElement e)
    {
        if (e.Type != "contact") return true;
        if (e.ContactType == "comparison")
        {
            double l = Numeric(e.Left), r = Numeric(e.Right); return e.Op switch { "eq" => l == r, "ne" => l != r, "gt" => l > r, "lt" => l < r, "ge" => l >= r, "le" => l <= r, _ => false };
        }
        bool v = simulator?.TryGetBool(e.Address, out var b) == true && b;
        return e.ContactType == "NC" ? !v : v;
    }
    private double Numeric(string s) { if (double.TryParse(s, out var n)) return n; if (simulator?.TryGetNumeric(s, out var v) == true) return v; if (simulator?.TryGetBool(s, out var b) == true) return b ? 1 : 0; return 0; }
    private void ToggleContact(string address)
    {
        if (simulator == null || !simulator.IsInput(address)) return;
        if (simulator.TryGetBool(address, out bool v)) simulator.SetBool(address, !v);
    }
    private static string OpText(string op) => op switch { "eq" => "=", "ne" => "≠", "gt" => ">", "lt" => "<", "ge" => "≥", "le" => "≤", _ => op };
    private void AddText(string text, double x, double y, double size, FontWeight weight, Brush brush) { var t = new TextBlock { Text = text, FontSize = size, FontWeight = weight, Foreground = brush }; Canvas.SetLeft(t, x); Canvas.SetTop(t, y); LadderCanvas.Children.Add(t); }
    private void AddLine(double x1, double y1, double x2, double y2, Brush brush, double thickness) => LadderCanvas.Children.Add(new Line { X1=x1,Y1=y1,X2=x2,Y2=y2,Stroke=brush,StrokeThickness=thickness,StrokeStartLineCap=PenLineCap.Round,StrokeEndLineCap=PenLineCap.Round });
}
