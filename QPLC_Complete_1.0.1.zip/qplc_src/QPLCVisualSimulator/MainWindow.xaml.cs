using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace QPLCVisualSimulator;

public partial class MainWindow : Window
{
    private LadderSimulator? simulator;
    private List<LadderNetwork> networks = new();
    private Config? config;
    private string? configPath;
    private string? ladderPath;
    private TagRow? selectedTag;

    public MainWindow() => InitializeComponent();

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        var baseDir = AppContext.BaseDirectory;
        configPath = Environment.GetEnvironmentVariable("QPLC_CONFIG") ?? Path.GetFullPath(Path.Combine(baseDir, "..", "..", "..", "..", "examples", "conf.qplc"));
        ladderPath = Environment.GetEnvironmentVariable("QPLC_LADDER") ?? Path.Combine(baseDir, "output.xml");
        if (File.Exists(configPath) && File.Exists(ladderPath)) LoadProject(); else StatusText.Text = "Open a QPLC config and ladder XML to start.";
    }

    private void LoadProject()
    {
        try
        {
            if (configPath == null || ladderPath == null) return;
            config = ConfigParser.Parse(configPath);
            networks = LadderXmlParser.Parse(ladderPath);
            simulator = new LadderSimulator(networks, config);
            simulator.Changed += Simulator_Changed;
            LadderViewControl.SetSimulator(simulator);
            RefreshAll();
            StatusText.Text = $"Loaded {Path.GetFileName(ladderPath)}";
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.ToString(), "QPLC project error", MessageBoxButton.OK, MessageBoxImage.Error);
            StatusText.Text = "Load failed";
        }
    }

    private void Simulator_Changed(object? sender, SimulationChangedEventArgs e) => Dispatcher.Invoke(RefreshAll);

    private void RefreshAll()
    {
        if (simulator == null || config == null) return;
        string filter = SearchBox.Text?.Trim() ?? "";
        var rows = simulator.GetTags()
            .Select(t => new TagRow(t.Name, t.Address, t.Type, t.BoolValue?.ToString().ToUpperInvariant() ?? t.NumericValue?.ToString("0.###") ?? "—", t.Forced, t.Kind.ToString()))
            .Where(x => filter.Length == 0 || x.Name.Contains(filter, StringComparison.OrdinalIgnoreCase) || x.Address.Contains(filter, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
        TagListView.ItemsSource = rows;
        VariableComboBox.ItemsSource = rows;
        if (selectedTag != null) selectedTag = rows.FirstOrDefault(x => x.Name.Equals(selectedTag.Name, StringComparison.OrdinalIgnoreCase));
        if (selectedTag != null) { SelectedTagText.Text = $"{selectedTag.Name}  |  {selectedTag.Address}"; ValueBox.Text = selectedTag.DisplayValue; }
        ProjectInfo.Text = $"CPU: {config.Hardware.Cpu}\nIP: {config.Hardware.Ip}\nNetworks: {networks.Count}";
        RuntimeInfo.Text = $"Scan {simulator.ScanCount}\nTime {simulator.CurrentTime:0.###} ms\nInstructions {simulator.LastInstructions}";
        StatusDetails.Text = simulator.WatchdogTripped ? "WATCHDOG TRIPPED" : $"Cycle {config.Runtime.CycleMs:0.###} ms | WD {config.Runtime.WatchdogMs:0.###} ms";
        StatusDetails.Foreground = new System.Windows.Media.SolidColorBrush(simulator.WatchdogTripped ? System.Windows.Media.Colors.OrangeRed : System.Windows.Media.Colors.LightGray);
        TraceListView.ItemsSource = simulator.Trace.TakeLast(100).Select(x => new TraceRow(x.Instruction, x.Network, x.PowerFlow ? "ON" : "OFF", x.Action)).Reverse().ToList();
        LadderViewControl.DrawNetworks(networks);
    }

    private void RunScan_Click(object sender, RoutedEventArgs e) => simulator?.RunScan();
    private void Reset_Click(object sender, RoutedEventArgs e) => simulator?.Reset();
    private void Tick_Click(object sender, RoutedEventArgs e)
    {
        if (simulator == null) return;
        if (!double.TryParse(CycleTimeBox.Text, out var ms) || ms < 0) { StatusText.Text = "Invalid cycle time"; return; }
        simulator.AdvanceTime(ms); simulator.RunScan();
    }

    private void SelectTag(TagRow row)
    {
        selectedTag = row;
        SelectedTagText.Text = $"{row.Name}  |  {row.Address}";
        ValueBox.Text = row.DisplayValue;
    }

    private void Variable_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (TagListView.SelectedItem is TagRow row) { SelectTag(row); if (simulator?.IsInput(row.Name) == true && simulator.TryGetBool(row.Name, out var v)) simulator.SetBool(row.Name, !v); }
    }
    private void TagListView_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (TagListView.SelectedItem is TagRow row) SelectTag(row); }

    private void ApplySet_Click(object sender, RoutedEventArgs e) => ApplyValue(false);
    private void ApplyForce_Click(object sender, RoutedEventArgs e) => ApplyValue(true);
    private void ApplyValue(bool force)
    {
        if (simulator == null || selectedTag == null) return;
        if (selectedTag.Type == "BOOL")
        {
            if (!bool.TryParse(ValueBox.Text, out var b)) { StatusText.Text = "BOOL value must be TRUE/FALSE"; return; }
            if (force) simulator.ForceBool(selectedTag.Name, b); else simulator.SetBool(selectedTag.Name, b);
        }
        else if (double.TryParse(ValueBox.Text, out var n)) { if (force) simulator.ForceNumeric(selectedTag.Name, n); else simulator.SetNumeric(selectedTag.Name, n); }
        else StatusText.Text = "Invalid numeric value";
    }
    private void ReleaseForce_Click(object sender, RoutedEventArgs e) { if (simulator != null && selectedTag != null) simulator.ReleaseForce(selectedTag.Name); }
    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) { if (IsLoaded) RefreshAll(); }

    private void OpenProject_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "QPLC config (*.qplc)|*.qplc|All files (*.*)|*.*", Title = "Select conf.qplc" };
        if (dlg.ShowDialog(this) != true) return;
        configPath = dlg.FileName;
        var ladderDlg = new OpenFileDialog { Filter = "Ladder XML (*.xml)|*.xml|All files (*.*)|*.*", Title = "Select generated ladder XML" };
        if (ladderDlg.ShowDialog(this) != true) return;
        ladderPath = ladderDlg.FileName;
        LoadProject();
    }
    private void Reload_Click(object sender, RoutedEventArgs e) => LoadProject();
}

public sealed record TagRow(string Name, string Address, string Type, string DisplayValue, bool Forced, string Kind)
{
    public string State => Forced ? "FORCED" : Kind.ToUpperInvariant()[..Math.Min(3, Kind.Length)];
}
public sealed record TraceRow(int Instruction, string Network, string Power, string Action);
