#include <cassert>
#include <string>
#include <vector>
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "semantic/semantic_analyzer.h"
#include "config/config_parser.h"
#include "codegen/ladder_generator.h"

static Config config() {
    const char* src = R"([runtime]
cycle_ms = 10
watchdog_ms = 100
max_instructions = 10000
retain_memory = true
reset_outputs_on_startup = true
[hardware]
cpu = S7-1214C
ip = 192.168.0.1
[io]
a = I0.0:BOOL
b = Q0.0:BOOL
x = IW64:REAL
out = Q1.0:BOOL[4]
input_array = I1.0:BOOL[4]
[memory]
p = M10.0:BOOL,retain
)";
    std::vector<ConfigError> errors; Config c = parseConfigWithErrors(src, errors); assert(errors.empty()); return c;
}

int main() {
    Config c = config();
    const std::string source = R"(def main():
    p = rising_edge(a)
    b = a and not p
    if x > 10.0:
        b = True
    else:
        b = False
    for i in range(0, 4, 2):
        out[i] = input_array[i]
    while a:
        b = True
        break
)";
    auto tokens = tokenize(source); Parser parser(tokens); auto p = parser.parseProgram();
    SemanticAnalyzer sa(c); auto errors = sa.analyze(*p); assert(errors.empty());
    const std::string xml = generateLadderXml(*p, c);
    assert(xml.find("version=\"1.0\"") != std::string::npos);
    assert(xml.find("<edge type=\"rising\"") != std::string::npos);
    assert(xml.find("Q1.2") != std::string::npos);
    assert(xml.find("WHILE_END") != std::string::npos);

    {
        const std::string invalid = R"(def main():
    a = True
    for i in range(2):
        break
)";
        auto bad = tokenize(invalid);
        Parser badParser(bad);
        auto badProgram = badParser.parseProgram();
        SemanticAnalyzer badSa(c);
        auto badErrors = badSa.analyze(*badProgram);
        assert(!badErrors.empty());
    }
    return 0;
}
