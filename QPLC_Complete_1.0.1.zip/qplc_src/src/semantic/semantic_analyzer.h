#pragma once

#include "ast/ast.h"
#include "config/config_parser.h"
#include "diagnostics/diagnostics.h"
#include <map>
#include <set>
#include <string>
#include <vector>

enum class ValueType { Invalid, Bool, Integer, Real, Time, Void };

struct SemanticError {
    int line{0}; int column{0}; std::string message;
};

class SemanticAnalyzer {
public:
    explicit SemanticAnalyzer(const Config& cfg);
    std::vector<SemanticError> analyze(const Program& program);
    const Diagnostics& diagnostics() const { return diagnostics_; }

private:
    const Config& config;
    std::vector<SemanticError> errors;
    Diagnostics diagnostics_;
    std::vector<std::set<std::string>> localVarScopes;
    int loopDepth{0};

    void enterScope();
    void exitScope();
    void addLocalVar(const std::string& name);
    bool isLocalVar(const std::string& name) const;
    ValueType exprType(const Expr& expr);
    ValueType variableType(const std::string& name) const;
    bool isNumeric(ValueType t) const;
    bool compatible(ValueType dst, ValueType src) const;
    void checkStmt(const Stmt& stmt);
    void checkBlock(const std::vector<StmtPtr>& body);
    void error(const Node& node,const std::string& code,const std::string& message,const std::string& hint = "");
    void warning(const Node& node,const std::string& code,const std::string& message,const std::string& hint = "");
    bool checkBuiltin(const CallExpr& call, ValueType& result);
};
