#include "semantic/semantic_analyzer.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <unordered_map>
#include <unordered_set>
using namespace std;

namespace {
struct Builtin { int minArgs; int maxArgs; ValueType result; vector<ValueType> args; };
const unordered_map<string,Builtin> builtins = {
    {"on_delay",{2,2,ValueType::Bool,{ValueType::Bool,ValueType::Time}}},
    {"off_delay",{2,2,ValueType::Bool,{ValueType::Bool,ValueType::Time}}},
    {"pulse",{2,2,ValueType::Bool,{ValueType::Bool,ValueType::Time}}},
    {"rising_edge",{1,1,ValueType::Bool,{ValueType::Bool}}},
    {"falling_edge",{1,1,ValueType::Bool,{ValueType::Bool}}},
    {"count_up",{3,3,ValueType::Bool,{ValueType::Bool,ValueType::Bool,ValueType::Integer}}},
    {"count_down",{3,3,ValueType::Bool,{ValueType::Bool,ValueType::Bool,ValueType::Integer}}},
    {"count_updown",{5,5,ValueType::Bool,{ValueType::Bool,ValueType::Bool,ValueType::Bool,ValueType::Bool,ValueType::Integer}}},
    {"sr_latch",{2,2,ValueType::Bool,{ValueType::Bool,ValueType::Bool}}},
    {"rs_latch",{2,2,ValueType::Bool,{ValueType::Bool,ValueType::Bool}}},
    {"abs",{1,1,ValueType::Real,{ValueType::Real}}},
    {"min",{2,2,ValueType::Real,{ValueType::Real,ValueType::Real}}},
    {"max",{2,2,ValueType::Real,{ValueType::Real,ValueType::Real}}},
    {"clamp",{3,3,ValueType::Real,{ValueType::Real,ValueType::Real,ValueType::Real}}},
};
bool isComparison(const string& op){return op=="=="||op=="!="||op=="<"||op==">"||op=="<="||op==">=";}
}
SemanticAnalyzer::SemanticAnalyzer(const Config& cfg):config(cfg){localVarScopes.push_back({});}
void SemanticAnalyzer::enterScope(){localVarScopes.push_back({});}
void SemanticAnalyzer::exitScope(){if(localVarScopes.size()>1)localVarScopes.pop_back();}
void SemanticAnalyzer::addLocalVar(const string& n){if(!localVarScopes.empty())localVarScopes.back().insert(n);}
bool SemanticAnalyzer::isLocalVar(const string& n)const{for(auto it=localVarScopes.rbegin();it!=localVarScopes.rend();++it)if(it->count(n))return true;return false;}
void SemanticAnalyzer::error(const Node& n,const string& c,const string& m,const string& h){errors.push_back({n.line,n.column,m});diagnostics_.push_back({DiagnosticSeverity::Error,c,n.line,n.column,m,h});}
void SemanticAnalyzer::warning(const Node& n,const string& c,const string& m,const string& h){diagnostics_.push_back({DiagnosticSeverity::Warning,c,n.line,n.column,m,h});}
ValueType SemanticAnalyzer::variableType(const string& name) const { if(isLocalVar(name))return ValueType::Integer;auto it=config.io.find(name);if(it==config.io.end())return ValueType::Invalid;if(it->second.type=="BOOL")return ValueType::Bool;if(it->second.type=="REAL")return ValueType::Real;if(it->second.type=="TIME")return ValueType::Time;return ValueType::Integer; }
bool SemanticAnalyzer::isNumeric(ValueType t)const{return t==ValueType::Integer||t==ValueType::Real;}
bool SemanticAnalyzer::compatible(ValueType dst,ValueType src)const{if(dst==src)return true;if(isNumeric(dst)&&isNumeric(src))return true;return false;}

bool SemanticAnalyzer::checkBuiltin(const CallExpr& c, ValueType& result){
    auto it=builtins.find(c.funcName);if(it==builtins.end())return false;const auto& b=it->second;
    if(static_cast<int>(c.args.size())<b.minArgs||static_cast<int>(c.args.size())>b.maxArgs){error(c,"SEM010","Builtin '"+c.funcName+"' expects "+to_string(b.minArgs)+(b.minArgs==b.maxArgs?"":".."+to_string(b.maxArgs))+" arguments, got "+to_string(c.args.size()));return true;}
    for(size_t i=0;i<c.args.size();++i){ValueType a=exprType(*c.args[i]);if(i<b.args.size()){ValueType expected=b.args[i];bool ok=false;if(expected==ValueType::Real)ok=isNumeric(a);else if(expected==ValueType::Integer)ok=a==ValueType::Integer;else ok=a==expected;if(!ok)error(*c.args[i],"SEM011","Invalid argument "+to_string(i+1)+" to '"+c.funcName+"'","expected a compatible type");}}
    result=b.result;return true;
}

ValueType SemanticAnalyzer::exprType(const Expr& e){
    if(dynamic_cast<const BoolExpr*>(&e))return ValueType::Bool;
    if(dynamic_cast<const TimeExpr*>(&e))return ValueType::Time;
    if(auto n=dynamic_cast<const NumberExpr*>(&e))return n->isFloat?ValueType::Real:ValueType::Integer;
    if(auto v=dynamic_cast<const VarExpr*>(&e)){ValueType t=variableType(v->name);if(t==ValueType::Invalid)error(*v,"SEM001","Variable '"+v->name+"' is not defined","add it to conf.qplc");return t;}
    if(auto idx=dynamic_cast<const IndexExpr*>(&e)){auto it=config.io.find(idx->name);if(it==config.io.end()){error(*idx,"SEM002","Variable '"+idx->name+"' is not defined");return ValueType::Invalid;}if(it->second.arrayLength<2)error(*idx,"SEM003","Variable '"+idx->name+"' is not an array");ValueType ix=exprType(*idx->index);if(ix!=ValueType::Integer)error(*idx->index,"SEM004","Array index must be an integer");if(auto n=dynamic_cast<const NumberExpr*>(idx->index.get())){int x=stoi(n->value);if(x<0||x>=it->second.arrayLength)error(*idx,"SEM005","Array index "+to_string(x)+" out of bounds for '"+idx->name+"'","length is "+to_string(it->second.arrayLength));}return variableType(idx->name);}
    if(auto a=dynamic_cast<const AttributeExpr*>(&e)){ValueType base=variableType(a->objectName);if(base==ValueType::Invalid)error(*a,"SEM006","Unknown object '"+a->objectName+"'");if(a->attrName=="Q"||a->attrName=="DN"||a->attrName=="UP")return ValueType::Bool;error(*a,"SEM007","Unknown attribute '"+a->attrName+"'");return ValueType::Invalid;}
    if(auto c=dynamic_cast<const CallExpr*>(&e)){ValueType r=ValueType::Invalid;if(checkBuiltin(*c,r))return r;error(*c,"SEM008","Unknown function '"+c->funcName+"'","only documented QPLC builtins are callable");return ValueType::Invalid;}
    if(auto u=dynamic_cast<const UnaryExpr*>(&e)){ValueType t=exprType(*u->operand);if(u->op=="not") {if(t!=ValueType::Bool)error(*u,"SEM012","'not' requires BOOL");return ValueType::Bool;}if(u->op=="~"){if(t!=ValueType::Integer)error(*u,"SEM013","'~' requires an integer");return ValueType::Integer;}if(u->op=="+"||u->op=="-"){if(!isNumeric(t))error(*u,"SEM014","Unary sign requires a numeric operand");return t;}}
    if(auto b=dynamic_cast<const BinaryExpr*>(&e)){ValueType l=exprType(*b->left),r=exprType(*b->right);if(b->op=="and"||b->op=="or"){if(l!=ValueType::Bool||r!=ValueType::Bool)error(*b,"SEM020","Boolean operator requires BOOL operands");return ValueType::Bool;}if(isComparison(b->op)){if(!(isNumeric(l)&&isNumeric(r))&&!(l==ValueType::Time&&r==ValueType::Time)&&!(l==ValueType::Bool&&r==ValueType::Bool))error(*b,"SEM021","Comparison operands have incompatible types");return ValueType::Bool;}if(b->op=="+"){if(l==ValueType::Time&&r==ValueType::Time){error(*b,"SEM022","TIME + TIME is not supported");return ValueType::Time;}if(!isNumeric(l)||!isNumeric(r))error(*b,"SEM023","Arithmetic operator requires numeric operands");return (l==ValueType::Real||r==ValueType::Real)?ValueType::Real:ValueType::Integer;}if(b->op=="-"||b->op=="*"||b->op=="/"||b->op=="//"||b->op=="%"||b->op=="|"||b->op=="&"||b->op=="^"){if(!isNumeric(l)||!isNumeric(r))error(*b,"SEM024","Arithmetic/bitwise operator requires numeric operands");if((b->op=="/"||b->op=="//"||b->op=="%")){if(auto n=dynamic_cast<const NumberExpr*>(b->right.get())){try{double v=stod(n->value);if(v==0.0)error(*b,"SEM025","Division or modulo by zero");}catch(...){}}}if(b->op=="/"||b->op=="%"||b->op=="-")return (l==ValueType::Real||r==ValueType::Real)?ValueType::Real:ValueType::Integer;return (l==ValueType::Real||r==ValueType::Real)?ValueType::Real:ValueType::Integer;}}
    return ValueType::Invalid;
}

void SemanticAnalyzer::checkBlock(const vector<StmtPtr>& body){for(const auto& s:body)checkStmt(*s);}
void SemanticAnalyzer::checkStmt(const Stmt& s){
    if(auto a=dynamic_cast<const AssignmentStmt*>(&s)){auto it=config.io.find(a->name);if(it==config.io.end()){error(*a,"SEM030","Variable '"+a->name+"' is not defined");return;}ValueType dst=variableType(a->name),src=exprType(*a->expr);if(!compatible(dst,src))error(*a,"SEM031","Cannot assign expression to '"+a->name+"'","destination and expression types are incompatible");if(it->second.kind==VariableKind::Input)error(*a,"SEM032","Cannot write to input tag '"+a->name+"'");return;}
    if(auto a=dynamic_cast<const IndexAssignmentStmt*>(&s)){auto it=config.io.find(a->name);if(it==config.io.end()){error(*a,"SEM033","Variable '"+a->name+"' is not defined");return;}if(it->second.arrayLength<2)error(*a,"SEM034","Variable '"+a->name+"' is not an array");ValueType ix=exprType(*a->index),src=exprType(*a->expr),dst=variableType(a->name);if(ix!=ValueType::Integer)error(*a,"SEM035","Array index must be integer");if(!compatible(dst,src))error(*a,"SEM036","Array assignment has incompatible types");if(it->second.kind==VariableKind::Input)error(*a,"SEM037","Cannot write to input array '"+a->name+"'");return;}
    if(auto i=dynamic_cast<const IfStmt*>(&s)){if(exprType(*i->cond)!=ValueType::Bool)error(*i,"SEM040","if condition must be BOOL");checkBlock(i->thenBlock);for(auto& b:i->elifBranches){if(exprType(*b.first)!=ValueType::Bool)error(*b.first,"SEM041","elif condition must be BOOL");checkBlock(b.second);}checkBlock(i->elseBlock);return;}
    if(auto f=dynamic_cast<const ForStmt*>(&s)){if(f->step==0)error(*f,"SEM042","for/range step cannot be zero");enterScope();addLocalVar(f->varName);checkBlock(f->body);exitScope();return;}
    if(auto w=dynamic_cast<const WhileStmt*>(&s)){if(exprType(*w->cond)!=ValueType::Bool)error(*w,"SEM043","while condition must be BOOL");++loopDepth;checkBlock(w->body);--loopDepth;return;}
    if(dynamic_cast<const BreakStmt*>(&s)){if(loopDepth==0)error(s,"SEM044","break is only valid inside a loop");return;}
    if(dynamic_cast<const ContinueStmt*>(&s)){if(loopDepth==0)error(s,"SEM045","continue is only valid inside a loop");return;}
    if(auto r=dynamic_cast<const ReturnStmt*>(&s)){error(*r,"SEM046","return is not allowed in cyclic PLC code","QPLC currently uses main() as the cyclic entry point");return;}
}

vector<SemanticError> SemanticAnalyzer::analyze(const Program& program){errors.clear();diagnostics_.clear();localVarScopes.clear();localVarScopes.push_back({});loopDepth=0;int mainCount=0;unordered_set<string> names;for(const auto& f:program.functions){if(!names.insert(f->name).second)diagnostics_.push_back({DiagnosticSeverity::Error,"SEM050",f->line,f->column,"Duplicate function '"+f->name+"'","remove or rename the duplicate function"});if(f->name=="main")++mainCount;if(f->name!="main"&&f->name!="init")diagnostics_.push_back({DiagnosticSeverity::Warning,"SEM051",f->line,f->column,"Function '"+f->name+"' is not part of the cyclic runtime","only main/init are emitted in v1.0"});}if(mainCount!=1)diagnostics_.push_back({DiagnosticSeverity::Error,"SEM052",0,0,"Program must contain exactly one main() function","main() is the cyclic entry point"});for(const auto& f:program.functions){if(f->name=="main"||f->name=="init"){enterScope();checkBlock(f->body);exitScope();}}return errors;}
