#include "lexer/lexer.h"

#include <cctype>
#include <regex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>

using namespace std;

namespace {
const unordered_set<string> keywords = {
    "def", "if", "elif", "else", "while", "for", "in", "range",
    "and", "or", "not", "return", "break", "continue",
    "True", "False", "true", "false"
};

bool isIdentifierStart(char c) { return std::isalpha(static_cast<unsigned char>(c)) || c == '_'; }
bool isIdentifierChar(char c) { return std::isalnum(static_cast<unsigned char>(c)) || c == '_'; }

int indentationWidth(const string& line) {
    int width = 0;
    bool sawSpace = false, sawTab = false;
    for (char c : line) {
        if (c == ' ') { ++width; sawSpace = true; }
        else if (c == '\t') { width += 4; sawTab = true; }
        else break;
    }
    if (sawSpace && sawTab) {
        throw runtime_error("Lexer error: mixed tabs and spaces in indentation");
    }
    return width;
}

size_t contentStart(const string& line) {
    size_t i = 0;
    while (i < line.size() && (line[i] == ' ' || line[i] == '\t')) ++i;
    return i;
}

void lexTime(const string& line, size_t& i, int lineNo, int col, vector<Token>& out) {
    const size_t start = i;
    i += 2; // T#
    bool foundUnit = false;
    bool foundAny = false;
    while (i < line.size()) {
        if (isdigit(static_cast<unsigned char>(line[i])) || line[i] == '.') { foundAny = true; ++i; continue; }
        if (line[i] == 'm' && i + 1 < line.size() && line[i + 1] == 's') { foundUnit = true; i += 2; continue; }
        if (line[i] == 'd' || line[i] == 'h' || line[i] == 'm' || line[i] == 's' || line[i] == 'u') { foundUnit = true; ++i; continue; }
        if (line[i] == '_') { ++i; continue; }
        break;
    }
    if (!foundAny || !foundUnit) throw runtime_error("Lexer error at line " + to_string(lineNo) + ": invalid TIME literal");
    out.emplace_back(TokenType::TIME_LITERAL, line.substr(start, i - start), lineNo, col);
}

void lexNumber(const string& line, size_t& i, int lineNo, int col, vector<Token>& out) {
    const size_t start = i;
    bool dot = false;
    bool digits = false;
    if (line[i] == '.') { dot = true; ++i; }
    while (i < line.size() && isdigit(static_cast<unsigned char>(line[i]))) { digits = true; ++i; }
    if (i < line.size() && line[i] == '.') {
        if (dot) throw runtime_error("Lexer error at line " + to_string(lineNo) + ": malformed number");
        dot = true; ++i;
        while (i < line.size() && isdigit(static_cast<unsigned char>(line[i]))) { digits = true; ++i; }
    }
    if (!digits) throw runtime_error("Lexer error at line " + to_string(lineNo) + ": malformed number");
    if (i < line.size() && (line[i] == 'e' || line[i] == 'E')) {
        dot = true; ++i;
        if (i < line.size() && (line[i] == '+' || line[i] == '-')) ++i;
        size_t expStart = i;
        while (i < line.size() && isdigit(static_cast<unsigned char>(line[i]))) ++i;
        if (expStart == i) throw runtime_error("Lexer error at line " + to_string(lineNo) + ": malformed exponent");
    }
    out.emplace_back(dot ? TokenType::FLOAT : TokenType::INTEGER, line.substr(start, i - start), lineNo, col);
}

void lexLine(const string& line, int lineNo, int baseCol, vector<Token>& out) {
    size_t i = 0;
    while (i < line.size()) {
        char c = line[i];
        int col = baseCol + static_cast<int>(i);
        if (c == ' ' || c == '\t' || c == '\r') { ++i; continue; }
        if (c == '#') break;

        if (c == 'T' && i + 1 < line.size() && line[i + 1] == '#') { lexTime(line, i, lineNo, col, out); continue; }

        if (isIdentifierStart(c)) {
            size_t start = i++;
            while (i < line.size() && isIdentifierChar(line[i])) ++i;
            string word = line.substr(start, i - start);
            out.emplace_back(keywords.count(word) ? TokenType::KEYWORD : TokenType::IDENTIFIER, word, lineNo, col);
            continue;
        }

        if (isdigit(static_cast<unsigned char>(c)) || (c == '.' && i + 1 < line.size() && isdigit(static_cast<unsigned char>(line[i + 1])))) {
            lexNumber(line, i, lineNo, col, out);
            continue;
        }

        if (i + 1 < line.size()) {
            string two = line.substr(i, 2);
            if (two == "==" || two == "!=" || two == "<=" || two == ">=" || two == "//" || two == "**" || two == "&&" || two == "||") {
                out.emplace_back(TokenType::OPERATOR, two, lineNo, col); i += 2; continue;
            }
        }
        if (string("=+-*/%<>&|^!~").find(c) != string::npos) {
            out.emplace_back(TokenType::OPERATOR, string(1, c), lineNo, col); ++i; continue;
        }
        if (string("():[],.").find(c) != string::npos) {
            out.emplace_back(TokenType::PUNCTUATION, string(1, c), lineNo, col); ++i; continue;
        }

        throw runtime_error("Lexer error at line " + to_string(lineNo) + ", column " + to_string(col) + ": unexpected character '" + string(1, c) + "'");
    }
}
}

vector<Token> tokenize(const string& source) {
    vector<Token> tokens;
    istringstream input(source);
    string line;
    int lineNo = 0;
    vector<int> indents{0};
    bool logicalLine = false;

    while (getline(input, line)) {
        ++lineNo;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        size_t start = contentStart(line);
        if (start == line.size() || line[start] == '#') continue;
        int indent = indentationWidth(line);
        if (indent > indents.back()) {
            indents.push_back(indent);
            tokens.emplace_back(TokenType::INDENT, "", lineNo, indent + 1);
        } else if (indent < indents.back()) {
            while (indents.size() > 1 && indent < indents.back()) {
                indents.pop_back();
                tokens.emplace_back(TokenType::DEDENT, "", lineNo, indent + 1);
            }
            if (indent != indents.back()) throw runtime_error("Lexer error at line " + to_string(lineNo) + ": inconsistent indentation");
        }
        lexLine(line.substr(start), lineNo, indent + 1, tokens);
        tokens.emplace_back(TokenType::NEWLINE, "", lineNo, static_cast<int>(line.size()) + 1);
        logicalLine = true;
    }
    if (logicalLine) {
        while (indents.size() > 1) { indents.pop_back(); tokens.emplace_back(TokenType::DEDENT, "", lineNo + 1, 1); }
    }
    tokens.emplace_back(TokenType::END_OF_FILE, "", lineNo + 1, 1);
    return tokens;
}

string tokenTypeToString(TokenType type) {
    switch (type) {
        case TokenType::IDENTIFIER: return "IDENTIFIER";
        case TokenType::KEYWORD: return "KEYWORD";
        case TokenType::INTEGER: return "INTEGER";
        case TokenType::FLOAT: return "FLOAT";
        case TokenType::TIME_LITERAL: return "TIME_LITERAL";
        case TokenType::OPERATOR: return "OPERATOR";
        case TokenType::PUNCTUATION: return "PUNCTUATION";
        case TokenType::INDENT: return "INDENT";
        case TokenType::DEDENT: return "DEDENT";
        case TokenType::NEWLINE: return "NEWLINE";
        case TokenType::END_OF_FILE: return "END_OF_FILE";
    }
    return "UNKNOWN";
}
