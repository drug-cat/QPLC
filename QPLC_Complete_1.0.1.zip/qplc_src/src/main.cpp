#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "config/config_parser.h"
#include "diagnostics/diagnostics.h"
#include "lexer/lexer.h"
#include "parser/parser.h"
#include "semantic/semantic_analyzer.h"
#include "codegen/ladder_generator.h"

using namespace std;

static string readFile(const string& path) {
    ifstream f(path, ios::binary);
    if (!f) throw runtime_error("Cannot open file '" + path + "'");
    stringstream ss; ss << f.rdbuf(); return ss.str();
}
static void usage() {
    cerr << "QPLC compiler 1.0\n"
         << "Usage:\n"
         << "  qplc <conf.qplc> <program.q> [-o output.xml] [--check] [--warnings-as-errors]\n"
         << "  qplc --tokens <program.q>\n"
         << "  qplc --version\n";
}
static void printDiagnostics(const Diagnostics& ds) {
    for (const auto& d : ds) cerr << d.format() << '\n';
}

int main(int argc, char* argv[]) {
    if (argc < 2) { usage(); return 2; }
    try {
        if (string(argv[1]) == "--version") { cout << "QPLC 1.0.0 industrial toolchain\n"; return 0; }
        if (string(argv[1]) == "--tokens") {
            if (argc < 3) { usage(); return 2; }
            for (const auto& t : tokenize(readFile(argv[2])))
                cout << t.line << ':' << t.column << "  " << tokenTypeToString(t.type) << "  " << t.lexeme << '\n';
            return 0;
        }
        if (argc < 3) { usage(); return 2; }

        string confPath = argv[1], sourcePath = argv[2], outPath;
        bool checkOnly = false, warningsAsErrors = false;
        for (int i = 3; i < argc; ++i) {
            string arg = argv[i];
            if (arg == "-o" && i + 1 < argc) outPath = argv[++i];
            else if (arg == "--check") checkOnly = true;
            else if (arg == "--warnings-as-errors") warningsAsErrors = true;
            else throw runtime_error("Unknown argument '" + arg + "'");
        }

        Diagnostics diagnostics;
        Config config = parseConfigWithDiagnostics(readFile(confPath), diagnostics);
        const size_t configErrors = count_if(diagnostics.begin(), diagnostics.end(), [](const Diagnostic& d){ return d.severity == DiagnosticSeverity::Error; });
        if (configErrors) { cerr << "Configuration failed:\n"; printDiagnostics(diagnostics); return 1; }

        auto tokens = tokenize(readFile(sourcePath));
        Parser parser(tokens);
        auto program = parser.parseProgram();
        SemanticAnalyzer analyzer(config);
        analyzer.analyze(*program);
        diagnostics.insert(diagnostics.end(), analyzer.diagnostics().begin(), analyzer.diagnostics().end());
        const size_t errors = count_if(diagnostics.begin(), diagnostics.end(), [](const Diagnostic& d){ return d.severity == DiagnosticSeverity::Error; });
        const size_t warnings = count_if(diagnostics.begin(), diagnostics.end(), [](const Diagnostic& d){ return d.severity == DiagnosticSeverity::Warning; });
        if (errors || (warningsAsErrors && warnings)) { printDiagnostics(diagnostics); return 1; }
        if (checkOnly) { cout << "QPLC check OK: " << sourcePath << " (warnings=" << warnings << ")\n"; return 0; }

        string xml = generateLadderXml(*program, config);
        if (!outPath.empty()) {
            filesystem::path p(outPath);
            if (p.has_parent_path()) filesystem::create_directories(p.parent_path());
            ofstream out(outPath, ios::binary);
            if (!out) throw runtime_error("Cannot create output file '" + outPath + "'");
            out << xml;
            cerr << "QPLC 1.0: generated " << outPath << " (warnings=" << warnings << ")\n";
        } else cout << xml;
        return 0;
    } catch (const exception& ex) {
        cerr << "QPLC error: " << ex.what() << '\n';
        return 1;
    }
}
