#pragma once
#include <sstream>
#include <string>
#include <vector>

enum class DiagnosticSeverity { Error, Warning, Info };

struct Diagnostic {
    DiagnosticSeverity severity{DiagnosticSeverity::Error};
    std::string code;
    int line{0};
    int column{0};
    std::string message;
    std::string hint;

    std::string format() const {
        std::ostringstream out;
        if (line > 0) out << line << ':' << column << ' ';
        out << (severity == DiagnosticSeverity::Error ? "error" : severity == DiagnosticSeverity::Warning ? "warning" : "info");
        if (!code.empty()) out << '[' << code << ']';
        out << ": " << message;
        if (!hint.empty()) out << " (" << hint << ')';
        return out.str();
    }
};

using Diagnostics = std::vector<Diagnostic>;
