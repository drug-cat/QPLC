#pragma once

#include <string>
#include <unordered_map>
#include <vector>

#include "diagnostics/diagnostics.h"

enum class VariableKind { Input, Output, Memory };

struct IoMapping {
    std::string address;
    std::string type;       // BOOL, INT, DINT, REAL, TIME
    int arrayLength{1};
    bool retain{false};
    VariableKind kind{VariableKind::Memory};
};

struct HardwareConfig {
    std::string cpu;
    std::string ip;
};

struct RuntimeConfig {
    double cycleMs{10.0};
    double watchdogMs{100.0};
    long long maxInstructions{100000};
    bool retainMemory{true};
    bool resetOutputsOnStartup{true};
};

struct Config {
    HardwareConfig hardware;
    RuntimeConfig runtime;
    std::unordered_map<std::string, IoMapping> io;
};

struct ConfigError {
    int line;
    std::string message;
};

Config parseConfig(const std::string& source);
Config parseConfigWithErrors(const std::string& source, std::vector<ConfigError>& errors);
Config parseConfigWithDiagnostics(const std::string& source, Diagnostics& diagnostics);
const char* variableKindToString(VariableKind kind);
