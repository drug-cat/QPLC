#include "config/config_parser.h"

#include <algorithm>
#include <cctype>
#include <regex>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

using namespace std;

namespace {
string trim(const string& s) {
    const size_t a = s.find_first_not_of(" \t\r\n");
    if (a == string::npos) return "";
    const size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}
string upper(string s) {
    transform(s.begin(), s.end(), s.begin(), [](unsigned char c){ return static_cast<char>(toupper(c)); });
    return s;
}
bool validType(const string& t) {
    static const unordered_set<string> types = {"BOOL", "INT", "DINT", "REAL", "TIME"};
    return types.count(upper(t)) != 0;
}
bool validAddress(const string& a) {
    static const regex re(R"(^[IQM][XWDB]?[0-9]+(?:\.[0-7])?$)", regex::icase);
    return regex_match(a, re);
}
VariableKind inferKind(const string& section, const string& address) {
    if (section == "memory") return VariableKind::Memory;
    if (!address.empty()) {
        char c = static_cast<char>(toupper(static_cast<unsigned char>(address[0])));
        if (c == 'I') return VariableKind::Input;
        if (c == 'Q') return VariableKind::Output;
    }
    return VariableKind::Memory;
}
bool parseBool(const string& v, bool& out) {
    string u = upper(trim(v));
    if (u == "TRUE" || u == "1" || u == "YES" || u == "ON") { out = true; return true; }
    if (u == "FALSE" || u == "0" || u == "NO" || u == "OFF") { out = false; return true; }
    return false;
}
void add(Diagnostics& ds, DiagnosticSeverity sev, const string& code, int line, const string& msg, const string& hint = "") {
    ds.push_back({sev, code, line, 1, msg, hint});
}
}

const char* variableKindToString(VariableKind kind) {
    switch (kind) {
        case VariableKind::Input: return "input";
        case VariableKind::Output: return "output";
        case VariableKind::Memory: return "memory";
    }
    return "memory";
}

Config parseConfig(const string& source) {
    Diagnostics diagnostics;
    Config c = parseConfigWithDiagnostics(source, diagnostics);
    if (!diagnostics.empty()) {
        ostringstream out;
        for (const auto& d : diagnostics) if (d.severity == DiagnosticSeverity::Error) out << d.format() << '\n';
        if (out.str().empty()) return c;
        throw runtime_error(out.str());
    }
    return c;
}

Config parseConfigWithErrors(const string& source, vector<ConfigError>& errors) {
    Diagnostics diagnostics;
    Config c = parseConfigWithDiagnostics(source, diagnostics);
    errors.clear();
    for (const auto& d : diagnostics) if (d.severity == DiagnosticSeverity::Error) errors.push_back({d.line, d.message});
    return c;
}

Config parseConfigWithDiagnostics(const string& source, Diagnostics& diagnostics) {
    Config config;
    diagnostics.clear();
    istringstream input(source);
    string line, section;
    int lineNo = 0;

    while (getline(input, line)) {
        ++lineNo;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        string trimmed = trim(line);
        if (trimmed.empty() || trimmed[0] == '#') continue;

        if (trimmed.front() == '[' && trimmed.back() == ']') {
            section = upper(trimmed.substr(1, trimmed.size() - 2));
            continue;
        }

        const size_t eq = trimmed.find('=');
        if (eq == string::npos) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG001", lineNo, "Expected '='");
            continue;
        }
        string key = trim(trimmed.substr(0, eq));
        string value = trim(trimmed.substr(eq + 1));
        if (key.empty() || value.empty()) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG002", lineNo, "Key and value must not be empty");
            continue;
        }

        if (section == "HARDWARE") {
            if (key == "cpu") config.hardware.cpu = value;
            else if (key == "ip") config.hardware.ip = value;
            else add(diagnostics, DiagnosticSeverity::Warning, "CFG003", lineNo, "Unknown hardware key '" + key + "'");
            continue;
        }

        if (section == "RUNTIME") {
            try {
                if (key == "cycle_ms") config.runtime.cycleMs = stod(value);
                else if (key == "watchdog_ms") config.runtime.watchdogMs = stod(value);
                else if (key == "max_instructions") config.runtime.maxInstructions = stoll(value);
                else if (key == "retain_memory") { bool b; if (!parseBool(value,b)) throw invalid_argument("bool"); config.runtime.retainMemory=b; }
                else if (key == "reset_outputs_on_startup") { bool b; if (!parseBool(value,b)) throw invalid_argument("bool"); config.runtime.resetOutputsOnStartup=b; }
                else add(diagnostics, DiagnosticSeverity::Warning, "CFG004", lineNo, "Unknown runtime key '" + key + "'");
            } catch (...) {
                add(diagnostics, DiagnosticSeverity::Error, "CFG005", lineNo, "Invalid runtime value for '" + key + "'");
            }
            continue;
        }

        if (section != "IO" && section != "MEMORY") {
            add(diagnostics, DiagnosticSeverity::Error, "CFG006", lineNo, "Key/value outside a supported section: '" + key + "'");
            continue;
        }

        if (config.io.count(key)) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG007", lineNo, "Duplicate variable '" + key + "'");
            continue;
        }

        const size_t colon = value.rfind(':');
        if (colon == string::npos) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG008", lineNo, "Mapping must be address:type[,retain]");
            continue;
        }
        IoMapping m;
        m.address = trim(value.substr(0, colon));
        string typePart = trim(value.substr(colon + 1));

        vector<string> attrs;
        size_t comma = typePart.find(',');
        if (comma != string::npos) {
            string attrPart = typePart.substr(comma + 1);
            typePart = trim(typePart.substr(0, comma));
            string token;
            stringstream ss(attrPart);
            while (getline(ss, token, ',')) attrs.push_back(upper(trim(token)));
        }

        const size_t open = typePart.find('[');
        if (open != string::npos) {
            const size_t close = typePart.find(']', open + 1);
            if (close == string::npos || close != typePart.size() - 1) {
                add(diagnostics, DiagnosticSeverity::Error, "CFG009", lineNo, "Malformed array declaration for '" + key + "'");
                continue;
            }
            m.type = upper(trim(typePart.substr(0, open)));
            string n = trim(typePart.substr(open + 1, close - open - 1));
            try { m.arrayLength = stoi(n); } catch (...) { m.arrayLength = 0; }
            if (m.arrayLength < 2 || m.arrayLength > 65535) {
                add(diagnostics, DiagnosticSeverity::Error, "CFG010", lineNo, "Array length must be between 2 and 65535");
                continue;
            }
        } else {
            m.type = upper(typePart);
            m.arrayLength = 1;
        }

        for (const auto& attr : attrs) {
            if (attr == "RETAIN" || attr == "RETENTIVE") m.retain = true;
            else add(diagnostics, DiagnosticSeverity::Warning, "CFG011", lineNo, "Unknown mapping attribute '" + attr + "'");
        }

        if (!validType(m.type)) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG012", lineNo, "Unsupported type '" + m.type + "'");
            continue;
        }
        if (!validAddress(m.address)) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG013", lineNo, "Invalid PLC address '" + m.address + "'");
            continue;
        }
        if (m.type == "BOOL" && m.address.find('.') == string::npos) {
            add(diagnostics, DiagnosticSeverity::Error, "CFG014", lineNo, "BOOL addresses must use bit notation such as M10.0");
            continue;
        }
        if (section == "MEMORY" && !m.address.empty() && toupper(static_cast<unsigned char>(m.address[0])) != 'M') {
            add(diagnostics, DiagnosticSeverity::Error, "CFG015", lineNo, "[memory] tags must use M memory addresses");
            continue;
        }
        m.kind = inferKind(section, m.address);
        config.io.emplace(key, m);
    }

    if (config.hardware.cpu.empty()) add(diagnostics, DiagnosticSeverity::Error, "CFG100", 0, "Missing [hardware] cpu");
    if (config.hardware.ip.empty()) add(diagnostics, DiagnosticSeverity::Error, "CFG101", 0, "Missing [hardware] ip");
    if (config.io.empty()) add(diagnostics, DiagnosticSeverity::Error, "CFG102", 0, "No variables defined");
    if (config.runtime.cycleMs <= 0) add(diagnostics, DiagnosticSeverity::Error, "CFG103", 0, "runtime.cycle_ms must be > 0");
    if (config.runtime.watchdogMs <= 0) add(diagnostics, DiagnosticSeverity::Error, "CFG104", 0, "runtime.watchdog_ms must be > 0");
    if (config.runtime.maxInstructions <= 0) add(diagnostics, DiagnosticSeverity::Error, "CFG105", 0, "runtime.max_instructions must be > 0");
    return config;
}
