using System;
using System.Linq;

namespace QPLCExporter;

internal static class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 2) { Console.WriteLine("QPLCExporter 1.0 | Usage: QPLCExporter <conf.qplc> <ladder.xml>"); return; }
        try
        {
            var config = ConfigParser.Parse(args[0]);
            var networks = LadderXmlParser.Parse(args[1]);
            int rungs = networks.Sum(n => n.Rungs.Count);
            Console.WriteLine($"Validated QPLC project: CPU={config.Hardware.Cpu}, variables={config.Io.Count}, networks={networks.Count}, rungs={rungs}");
            TiaProjectBuilder.Build(config, networks);
        }
        catch (Exception ex) { Console.Error.WriteLine($"QPLCExporter error: {ex.Message}"); Environment.ExitCode = 1; }
    }
}
