using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace QPLCExporter;

public enum VariableKind { Input, Output, Memory }
public sealed class IoMapping { public string Address { get; set; } = ""; public string Type { get; set; } = ""; public int ArrayLength { get; set; } = 1; public bool Retain { get; set; } public VariableKind Kind { get; set; } }
public sealed class HardwareConfig { public string Cpu { get; set; } = ""; public string Ip { get; set; } = ""; }
public sealed class RuntimeConfig { public double CycleMs { get; set; } = 10; public double WatchdogMs { get; set; } = 100; public long MaxInstructions { get; set; } = 100000; }
public sealed class Config { public HardwareConfig Hardware { get; set; } = new(); public RuntimeConfig Runtime { get; set; } = new(); public Dictionary<string,IoMapping> Io { get; set; } = new(StringComparer.OrdinalIgnoreCase); }

public static class ConfigParser
{
    public static Config Parse(string filePath)
    {
        if (!File.Exists(filePath)) throw new FileNotFoundException("QPLC config not found", filePath);
        var c = new Config(); string section = ""; int lineNo = 0;
        foreach (var raw in File.ReadLines(filePath))
        {
            lineNo++; string line = raw.Trim(); if (line.Length == 0 || line.StartsWith('#')) continue;
            if (line.StartsWith('[') && line.EndsWith(']')) { section = line[1..^1].Trim(); continue; }
            int eq = line.IndexOf('='); if (eq < 0) throw new InvalidDataException($"Line {lineNo}: expected '='");
            string key = line[..eq].Trim(), value = line[(eq+1)..].Trim();
            if (section.Equals("hardware",StringComparison.OrdinalIgnoreCase)) { if(key.Equals("cpu",StringComparison.OrdinalIgnoreCase)) c.Hardware.Cpu=value; else if(key.Equals("ip",StringComparison.OrdinalIgnoreCase)) c.Hardware.Ip=value; continue; }
            if (section.Equals("runtime",StringComparison.OrdinalIgnoreCase)) { if(key.Equals("cycle_ms",StringComparison.OrdinalIgnoreCase)) c.Runtime.CycleMs=double.Parse(value,CultureInfo.InvariantCulture); else if(key.Equals("watchdog_ms",StringComparison.OrdinalIgnoreCase)) c.Runtime.WatchdogMs=double.Parse(value,CultureInfo.InvariantCulture); else if(key.Equals("max_instructions",StringComparison.OrdinalIgnoreCase)) c.Runtime.MaxInstructions=long.Parse(value,CultureInfo.InvariantCulture); continue; }
            if (!section.Equals("io",StringComparison.OrdinalIgnoreCase) && !section.Equals("memory",StringComparison.OrdinalIgnoreCase)) continue;
            int colon=value.LastIndexOf(':'); if(colon<=0)throw new InvalidDataException($"Line {lineNo}: invalid mapping");
            string address=value[..colon].Trim(), typePart=value[(colon+1)..].Trim(); bool retain=false; int comma=typePart.IndexOf(',');
            if(comma>=0){foreach(var attr in typePart[(comma+1)..].Split(',',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries)){if(attr.Equals("retain",StringComparison.OrdinalIgnoreCase)||attr.Equals("retentive",StringComparison.OrdinalIgnoreCase))retain=true;}typePart=typePart[..comma].Trim();}
            int length=1, open=typePart.IndexOf('['); if(open>=0){if(!typePart.EndsWith(']'))throw new InvalidDataException($"Line {lineNo}: invalid array"); length=int.Parse(typePart[(open+1)..^1],CultureInfo.InvariantCulture);typePart=typePart[..open].Trim();}
            var kind=section.Equals("memory",StringComparison.OrdinalIgnoreCase)?VariableKind.Memory:address.StartsWith("I",StringComparison.OrdinalIgnoreCase)?VariableKind.Input:address.StartsWith("Q",StringComparison.OrdinalIgnoreCase)?VariableKind.Output:VariableKind.Memory;
            c.Io[key]=new IoMapping{Address=address,Type=typePart.ToUpperInvariant(),ArrayLength=length,Retain=retain,Kind=kind};
        }
        if(string.IsNullOrWhiteSpace(c.Hardware.Cpu)||string.IsNullOrWhiteSpace(c.Hardware.Ip))throw new InvalidDataException("Missing [hardware] cpu/ip");
        return c;
    }
}
