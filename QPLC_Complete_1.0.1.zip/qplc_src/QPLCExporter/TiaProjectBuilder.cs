using System;
using System.Collections.Generic;

namespace QPLCExporter;

public static class TiaProjectBuilder
{
#if TIA_OPENNESS_AVAILABLE
    public static void Build(Config config, List<LadderNetwork> networks)
    {
        using Siemens.Engineering.TiaPortal portal = new Siemens.Engineering.TiaPortal();
        string directory = System.IO.Path.GetFullPath(".");
        string name = "QPLC_Project";
        var project = portal.Projects.Create(new System.IO.DirectoryInfo(directory), name);
        Console.WriteLine($"Created TIA project '{project.Name}' for CPU {config.Hardware.Cpu}.");
        Console.WriteLine($"Networks: {networks.Count}. Device/tag/network import must match the installed TIA Portal version and its Openness schema.");
        project.Save(); project.Close(); portal.Dispose();
    }
#else
    public static void Build(Config config, List<LadderNetwork> networks)
    {
        Console.WriteLine("TIA Openness API is not installed/configured on this machine.");
        Console.WriteLine($"Validated project: CPU={config.Hardware.Cpu}, IO={config.Io.Count}, Networks={networks.Count}.");
        Console.WriteLine("Run this exporter with TIAOpennessPath=<TIA Portal installation API folder> to enable project creation.");
    }
#endif
}
