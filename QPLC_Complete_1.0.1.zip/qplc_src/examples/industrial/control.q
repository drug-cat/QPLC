def main():
    motor_run = start_button and not stop_button and not emergency
    start_pulse = rising_edge(start_button)
    stop_pulse = falling_edge(stop_button)

    if emergency:
        motor_run = False
    elif temperature > 80.0:
        motor_run = False
        cooling_valve = True
    elif temperature > 50.0:
        cooling_valve = True
    else:
        cooling_valve = False

    warmup_done = on_delay(start_button, T#2s)
    valve_hold = off_delay(stop_button, T#1s)
    heartbeat = pulse(start_pulse, T#250ms)
    reached = count_up(sensor, reset, 10)

    if reached:
        done = True

    for i in range(0, 4, 1):
        outputs[i] = inputs[i] and enable
