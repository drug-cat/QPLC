def main():
    first_scan = rising_edge(start_button)
    scaled = (temperature * 1.5) + 2
    if scaled >= 100.0:
        motor_run = False
    else:
        motor_run = enable

    for i in range(0, 4, 2):
        outputs[i] = inputs[i]
        outputs[i + 1] = inputs[i]

    while start_button and not stop_button:
        motor_run = enable
        break
