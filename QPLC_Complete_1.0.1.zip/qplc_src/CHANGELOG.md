# QPLC changelog

## 1.0.0

- Reworked compiler diagnostics and CLI.
- Hardened indentation-aware lexer.
- Added `break`, `continue`, `range(..., step)`, lowercase boolean literals and additional operators.
- Added stronger semantic typing and builtin signatures.
- Added rising/falling edge functions.
- Added SR/RS latch functions.
- Added runtime watchdog/cycle/retention configuration.
- Added `[memory]` configuration section and `retain` mapping attribute.
- Added real jump/label scan execution model to the simulator.
- Added numeric expression evaluator to simulator MOVE execution.
- Added force/release controls and execution trace.
- Added industrial-oriented WPF simulator layout.
- Added offline-safe TIA exporter boundary.
- Added compiler unit tests and CTest coverage.
- Added industrial example projects.

## 0.x lineage

See the previous project history for the original minimal lexer/parser/ladder simulator implementation.
