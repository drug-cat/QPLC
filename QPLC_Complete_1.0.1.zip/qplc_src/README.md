# QPLC 1.0 — Industrial-oriented High-Level PLC Language for Siemens S7

QPLC is a high-level, scan-cycle PLC language designed around Siemens-style I/O addressing and a ladder-oriented execution model. It is intentionally deterministic and compiler-first: source code is lexed, parsed into an AST, semantically checked, and lowered to a ladder XML runtime representation consumed by the simulator/export pipeline.

> **Engineering boundary:** this repository is an engineering/development toolchain. It is not a certified safety PLC runtime, SIL/PL product, or a replacement for Siemens/TIA Portal validation on real hardware.

## What changed in 1.0

### Compiler pipeline

- Production-oriented diagnostics with severity, codes, source locations, and hints.
- Stronger lexer: indentation checking, malformed-number detection, scientific notation, composite TIME literals, `&&`/`||`/`!`, `%`, `//`, bitwise operators and additional loop keywords.
- Recursive-descent parser with:
  - `if / elif / else`
  - `for ... in range(start, end[, step])`
  - `while`
  - `break / continue`
  - `return` syntax with an explicit cyclic-code diagnostic
  - array indexing and attribute access
  - builtin function calls
- Semantic analysis for BOOL, integer, REAL and TIME expressions, array bounds, write-protection of inputs, builtin signatures, invalid operators and constant division-by-zero.
- `main()` is the cyclic entry point. `init()` is recognized as a reserved lifecycle function for future startup lowering; non-runtime helper functions produce a warning.
- `--check` and `--warnings-as-errors` modes.
- `--version` and token inspection CLI.

### Industrial configuration

`conf.qplc` now supports:

```ini
[runtime]
cycle_ms = 10
watchdog_ms = 100
max_instructions = 100000
retain_memory = true
reset_outputs_on_startup = true

[hardware]
cpu = S7-1214C
ip = 192.168.0.1

[io]
start = I0.0:BOOL
motor = Q0.0:BOOL
speed = QW80:INT

[memory]
latched = M10.0:BOOL,retain
counter = MW20:DINT,retain
```

Variables in `[io]` are automatically classified by address (`I` = input, `Q` = output). `[memory]` requires `M` addresses and supports retention metadata.

### Language builtins

Timers:

```q
ton = on_delay(input, T#2s)
tof = off_delay(input, T#1s)
tp = pulse(trigger, T#250ms)
```

Edges:

```q
start_pulse = rising_edge(start_button)
stop_pulse = falling_edge(stop_button)
```

Counters:

```q
done = count_up(sensor, reset, 10)
finished = count_down(input, load, 5)
reached = count_updown(up, down, reset, load, 100)
```

Latches:

```q
motor_latched = sr_latch(start, stop)
trip_latched = rs_latch(reset, trip)
```

Numeric helpers:

```q
a = abs(x)
b = min(x, y)
c = max(x, y)
d = clamp(x, low, high)
```

### Runtime / simulator

The new simulator runtime models a deterministic instruction pointer instead of simply iterating XML networks:

- real `JMP/JMPN/LABEL` execution
- bounded instruction watchdog
- scan count / instruction telemetry
- TON / TOF / TP timer state
- edge-trigger state
- CTU / CTD / CTUD-style counter state with rising-edge counting
- SR / RS latch semantics
- numeric expression evaluation for `MOVE`
- force vs normal set/release state
- retained memory handling
- trace buffer for recent scan instructions
- live tag state inspection

The WPF simulator was rebuilt as an engineering console with project/runtime cards, tag monitoring, force/release, trace view, live power flow ladder drawing, searchable tags and watchdog indication.

### Export layer

The exporter now has two modes:

1. **Offline validation mode** — works without Siemens DLLs and validates the QPLC config/XML model.
2. **TIA Openness mode** — enabled only when `TIAOpennessPath` points to an installation containing `Siemens.Engineering.dll`.

This prevents the project itself from failing to compile on machines without Siemens Openness installed.

## CLI

```text
qplc <conf.qplc> <program.q> [-o output.xml]
qplc <conf.qplc> <program.q> --check
qplc <conf.qplc> <program.q> --check --warnings-as-errors
qplc --tokens <program.q>
qplc --version
```

Build and test:

```powershell
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

Or:

```powershell
.\build.ps1
```

## Examples

- `examples/main.q` — minimal timer
- `examples/test_all.q` — broad syntax/runtime sample
- `examples/industrial/control.q` + `control.conf.qplc` — industrial-oriented cyclic example
- `examples/industrial/stress.q` + `memory.conf.qplc` — arithmetic, arrays, while/break and retentive memory configuration

## Architectural direction

The current XML is a deliberately simple interchange/runtime representation. The next major architectural step is to split lowering into explicit typed IR + machine-independent runtime IR, then provide dedicated Siemens S7-1200/S7-1500 backends and a deterministic memory-layout layer. That is the recommended foundation for future FB/FC support, structures, enums, richer IEC 61131-3 typing, source maps, online diagnostics, optimized code generation and real TIA Openness project generation.
