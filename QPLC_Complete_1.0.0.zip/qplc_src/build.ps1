$ErrorActionPreference = 'Stop'

Write-Host '== QPLC compiler 1.0 ==' -ForegroundColor Cyan
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure

if (Get-Command dotnet -ErrorAction SilentlyContinue) {
  Write-Host '== QPLC visual simulator ==' -ForegroundColor Cyan
  dotnet build .\QPLCVisualSimulator\QPLCVisualSimulator.csproj -c Release
  Write-Host '== QPLC text simulator ==' -ForegroundColor Cyan
  dotnet build .\QPLCSimulator\QPLCSimulator.csproj -c Release
  Write-Host '== QPLC exporter ==' -ForegroundColor Cyan
  dotnet build .\QPLCExporter\QPLCExporter.csproj -c Release
} else {
  Write-Host 'dotnet SDK not found; C++ compiler/tests completed, .NET projects were not build-verified on this host.' -ForegroundColor Yellow
}

Write-Host 'Build completed.' -ForegroundColor Green
