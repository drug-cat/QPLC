using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace QPLCVisualSimulator;

public sealed class SimulationChangedEventArgs : EventArgs
{
    public SimulationChangedEventArgs(string reason, long scan, long instructions, double time, bool watchdog) { Reason = reason; Scan = scan; Instructions = instructions; Time = time; WatchdogTripped = watchdog; }
    public string Reason { get; }
    public long Scan { get; }
    public long Instructions { get; }
    public double Time { get; }
    public bool WatchdogTripped { get; }
}

public sealed class TraceEntry
{
    public long Scan { get; init; }
    public int Instruction { get; init; }
    public string Network { get; init; } = "";
    public string Action { get; init; } = "";
    public bool PowerFlow { get; init; }
}

public sealed class TagState
{
    public string Name { get; init; } = "";
    public string Address { get; init; } = "";
    public string Type { get; init; } = "";
    public VariableKind Kind { get; init; }
    public bool Retain { get; init; }
    public bool Forced { get; init; }
    public bool? BoolValue { get; init; }
    public double? NumericValue { get; init; }
}

public class LadderSimulator
{
    private readonly List<LadderNetwork> networks;
    private readonly Config config;
    private readonly Dictionary<string, bool> boolVars = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, double> numVars = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, bool> forcedBool = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, double> forcedNum = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, TimerInstance> timers = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, CounterInstance> counters = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, EdgeState> edges = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, (int Network, int Rung)> labels = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<TraceEntry> trace = new();
    private readonly Dictionary<string, IoMapping> mappingByAddress = new(StringComparer.OrdinalIgnoreCase);
    private bool initialized;

    public LadderSimulator(List<LadderNetwork> networks, Config config)
    {
        this.networks = networks;
        this.config = config;
        BuildLabelMap();
        InitializeVariables();
    }

    public event EventHandler<SimulationChangedEventArgs>? Changed;
    public double CurrentTime { get; private set; }
    public long ScanCount { get; private set; }
    public long LastInstructions { get; private set; }
    public bool WatchdogTripped { get; private set; }
    public IReadOnlyDictionary<string, CounterInstanceView> Counters => counters.ToDictionary(k => k.Key, v => new CounterInstanceView(v.Value.Count, v.Value.Preset), StringComparer.OrdinalIgnoreCase);
    public IReadOnlyList<TraceEntry> Trace => trace;
    public IReadOnlyDictionary<string, bool> BoolVariables => boolVars;
    public IReadOnlyDictionary<string, double> NumericVariables => numVars;

    private void BuildLabelMap()
    {
        for (int ni = 0; ni < networks.Count; ni++) for (int ri = 0; ri < networks[ni].Rungs.Count; ri++) if (networks[ni].Rungs[ri].Label is { Label: var label } && !string.IsNullOrWhiteSpace(label)) labels[label] = (ni, ri);
    }

    private void InitializeVariables()
    {
        foreach (var (name, m) in config.Io)
        {
            for (int i = 0; i < m.ArrayLength; i++)
            {
                var logical = m.ArrayLength > 1 ? $"{name}[{i}]" : name;
                var address = AddressFor(m, i);
                mappingByAddress[address] = m;
                if (m.Type == "BOOL") boolVars.TryAdd(logical, false);
                else numVars.TryAdd(logical, 0);
                boolVars.TryAdd(address, false);
                if (m.Type != "BOOL") numVars.TryAdd(address, 0);
            }
        }
        foreach (var network in networks)
            foreach (var rung in network.Rungs)
            {
                foreach (var branch in rung.Branches) foreach (var e in branch) RegisterElement(e);
                if (rung.Coil is { } coil) boolVars.TryAdd(coil.Address, false);
                if (rung.Move is { } move) { AddUnknown(move.Dest); AddUnknown(move.Source); }
                if (rung.Timer is { } timer) boolVars.TryAdd(timer.Address, false);
                if (rung.Counter is { } counter) boolVars.TryAdd(counter.Address, false);
                if (rung.Edge is { } edge) boolVars.TryAdd(edge.Address, false);
                if (rung.Latch is { } latch) boolVars.TryAdd(latch.Address, false);
            }
        initialized = true;
    }

    private void RegisterElement(LadderElement e)
    {
        if (e.Type == "contact")
        {
            if (e.ContactType.Equals("comparison", StringComparison.OrdinalIgnoreCase)) { AddUnknown(e.Left); AddUnknown(e.Right); }
            else if (!e.ContactType.Equals("comparison", StringComparison.OrdinalIgnoreCase)) boolVars.TryAdd(e.Address, false);
        }
    }

    private void AddUnknown(string? expr)
    {
        if (string.IsNullOrWhiteSpace(expr) || double.TryParse(expr, NumberStyles.Float, CultureInfo.InvariantCulture, out _)) return;
        if (boolVars.ContainsKey(expr) || numVars.ContainsKey(expr)) return;
        if (expr.StartsWith("T#", StringComparison.OrdinalIgnoreCase)) return;
        numVars[expr] = 0;
    }

    public bool IsInput(string name)
    {
        if (config.Io.TryGetValue(name, out var m)) return m.Kind == VariableKind.Input;
        if (mappingByAddress.TryGetValue(name, out m)) return m.Kind == VariableKind.Input;
        return name.StartsWith('I');
    }

    public bool IsOutput(string name)
    {
        if (config.Io.TryGetValue(name, out var m)) return m.Kind == VariableKind.Output;
        if (mappingByAddress.TryGetValue(name, out m)) return m.Kind == VariableKind.Output;
        return name.StartsWith('Q');
    }

    public bool TryGetBool(string name, out bool value)
    {
        if (forcedBool.TryGetValue(name, out value)) return true;
        return boolVars.TryGetValue(name, out value);
    }

    public bool TryGetNumeric(string name, out double value)
    {
        if (forcedNum.TryGetValue(name, out value)) return true;
        return numVars.TryGetValue(name, out value);
    }

    public void SetBool(string name, bool value)
    {
        boolVars[name] = value;
        Changed?.Invoke(this, new SimulationChangedEventArgs($"set {name}", ScanCount, LastInstructions, CurrentTime, WatchdogTripped));
    }

    public void SetNumeric(string name, double value)
    {
        numVars[name] = value;
        Changed?.Invoke(this, new SimulationChangedEventArgs($"set {name}", ScanCount, LastInstructions, CurrentTime, WatchdogTripped));
    }

    public void ForceBool(string name, bool value) { forcedBool[name] = value; boolVars[name] = value; Changed?.Invoke(this, new SimulationChangedEventArgs($"force {name}", ScanCount, LastInstructions, CurrentTime, WatchdogTripped)); }
    public void ForceNumeric(string name, double value) { forcedNum[name] = value; numVars[name] = value; Changed?.Invoke(this, new SimulationChangedEventArgs($"force {name}", ScanCount, LastInstructions, CurrentTime, WatchdogTripped)); }
    public void ReleaseForce(string name) { forcedBool.Remove(name); forcedNum.Remove(name); Changed?.Invoke(this, new SimulationChangedEventArgs($"release {name}", ScanCount, LastInstructions, CurrentTime, WatchdogTripped)); }

    public IEnumerable<TagState> GetTags()
    {
        foreach (var (name, m) in config.Io)
            for (int i = 0; i < m.ArrayLength; i++)
            {
                var logical = m.ArrayLength > 1 ? $"{name}[{i}]" : name;
                yield return m.Type == "BOOL"
                    ? new TagState { Name = logical, Address = AddressFor(m, i), Type = m.Type, Kind = m.Kind, Retain = m.Retain, Forced = forcedBool.ContainsKey(logical), BoolValue = TryGetBool(logical, out var b) ? b : false }
                    : new TagState { Name = logical, Address = AddressFor(m, i), Type = m.Type, Kind = m.Kind, Retain = m.Retain, Forced = forcedNum.ContainsKey(logical), NumericValue = TryGetNumeric(logical, out var n) ? n : 0 };
            }
    }

    public void AdvanceTime(double ms)
    {
        if (ms < 0) throw new ArgumentOutOfRangeException(nameof(ms));
        CurrentTime += ms;
        Changed?.Invoke(this, new SimulationChangedEventArgs("time advance", ScanCount, LastInstructions, CurrentTime, WatchdogTripped));
    }

    public void Reset()
    {
        foreach (var (name, m) in config.Io)
            for (int i = 0; i < m.ArrayLength; i++)
            {
                var logical = m.ArrayLength > 1 ? $"{name}[{i}]" : name;
                bool retain = config.Runtime.RetainMemory && m.Retain && m.Kind == VariableKind.Memory;
                if (!retain) { if (m.Type == "BOOL") boolVars[logical] = false; else numVars[logical] = 0; }
                if (config.Runtime.ResetOutputsOnStartup && m.Kind == VariableKind.Output) { if (m.Type == "BOOL") boolVars[logical] = false; else numVars[logical] = 0; }
                var addr = AddressFor(m, i);
                if (!retain) { boolVars[addr] = false; if (m.Type != "BOOL") numVars[addr] = 0; }
            }
        timers.Clear(); counters.Clear(); edges.Clear(); trace.Clear(); CurrentTime = 0; ScanCount = 0; LastInstructions = 0; WatchdogTripped = false;
        Changed?.Invoke(this, new SimulationChangedEventArgs("reset", ScanCount, LastInstructions, CurrentTime, false));
    }

    public void RunScan()
    {
        if (!initialized) return;
        WatchdogTripped = false;
        LastInstructions = 0;
        var sw = Stopwatch.StartNew();
        int ni = 0, ri = 0;
        while (ni >= 0 && ni < networks.Count)
        {
            if (ri >= networks[ni].Rungs.Count) { ni++; ri = 0; continue; }
            var rung = networks[ni].Rungs[ri];
            LastInstructions++;
            bool power = EvaluateRungCondition(rung);
            trace.Add(new TraceEntry { Scan = ScanCount + 1, Instruction = (int)LastInstructions, Network = networks[ni].Name, Action = Describe(rung), PowerFlow = power });
            if (trace.Count > 2000) trace.RemoveAt(0);

            if (rung.Coil is { } coil) ApplyCoil(coil, power);
            if (rung.Move is { } move && power) SetNumeric(move.Dest, EvaluateNumeric(move.Source));
            if (rung.Timer is { } timer) ProcessTimer(timer, power);
            if (rung.Counter is { } counter) ProcessCounter(counter);
            if (rung.Edge is { } edge) ProcessEdge(edge, power);
            if (rung.Latch is { } latch) ProcessLatch(latch);

            if (rung.Jump is { } jump)
            {
                bool doJump = jump.JumpType.Equals("jmp", StringComparison.OrdinalIgnoreCase) ? power : !power;
                if (doJump && labels.TryGetValue(jump.Label, out var target)) { ni = target.Network; ri = target.Rung; continue; }
            }

            ri++;
            if (LastInstructions > config.Runtime.MaxInstructions || sw.Elapsed.TotalMilliseconds > config.Runtime.WatchdogMs)
            {
                WatchdogTripped = true;
                break;
            }
        }
        ScanCount++;
        Changed?.Invoke(this, new SimulationChangedEventArgs(WatchdogTripped ? "watchdog" : "scan", ScanCount, LastInstructions, CurrentTime, WatchdogTripped));
    }

    private void ApplyCoil(LadderElement coil, bool power)
    {
        if (forcedBool.ContainsKey(coil.Address)) return;
        if (coil.ContactType.Equals("reset", StringComparison.OrdinalIgnoreCase)) { if (power) boolVars[coil.Address] = false; }
        else if (coil.ContactType.Equals("set", StringComparison.OrdinalIgnoreCase)) { if (power) boolVars[coil.Address] = true; }
        else boolVars[coil.Address] = power;
    }

    private void ProcessTimer(LadderElement e, bool input)
    {
        string key = e.Address;
        double duration = ParseTimeLiteral(e.Duration.Length > 0 ? e.Duration : e.Source);
        if (!timers.TryGetValue(key, out var t)) { t = new TimerInstance(); timers[key] = t; }
        bool prev = t.Input;
        t.PrevInput = prev; t.Input = input; t.DurationMs = duration; t.Type = e.ContactType;
        switch (t.Type)
        {
            case "on_delay":
                if (input) { if (!prev) t.StartTime = CurrentTime; t.Output = CurrentTime - t.StartTime >= duration; }
                else { t.Output = false; t.StartTime = CurrentTime; }
                break;
            case "off_delay":
                if (input) { t.Output = true; t.StartTime = CurrentTime; }
                else { if (prev) t.StartTime = CurrentTime; t.Output = CurrentTime - t.StartTime < duration; }
                break;
            case "pulse":
                if (input && !prev) t.StartTime = CurrentTime;
                t.Output = input && CurrentTime - t.StartTime < duration;
                break;
            default: t.Output = false; break;
        }
        boolVars[key] = t.Output;
    }

    private void ProcessCounter(LadderElement e)
    {
        string key = e.Address;
        if (!counters.TryGetValue(key, out var c)) { c = new CounterInstance(); counters[key] = c; }
        c.Type = e.ContactType; c.Preset = (int)Math.Round(EvaluateNumeric(e.Preset));
        bool a = EvaluateBool(e.Input1), b = EvaluateBool(e.Input2), c3 = EvaluateBool(e.Input3), d = EvaluateBool(e.Input4);
        bool ea = a && !c.Prev1, eb = b && !c.Prev2;
        switch (c.Type)
        {
            case "count_up": if (b) c.Count = 0; else if (ea) c.Count++; break;
            case "count_down": if (b) c.Count = c.Preset; else if (ea) c.Count--; break;
            case "count_updown": if (c3) c.Count = 0; else if (d) c.Count = c.Preset; else { if (ea) c.Count++; if (eb) c.Count--; } break;
        }
        c.Count = Math.Clamp(c.Count, -32768, 32767);
        c.Output = c.Count >= c.Preset;
        c.Prev1=a;c.Prev2=b;c.Prev3=c3;c.Prev4=d; boolVars[key]=c.Output;
    }

    private void ProcessEdge(LadderElement e, bool power)
    {
        if (!edges.TryGetValue(e.Address, out var state)) { state = new EdgeState(); edges[e.Address] = state; }
        bool prev = state.Previous; bool result = e.EdgeType.Equals("rising", StringComparison.OrdinalIgnoreCase) ? power && !prev : !power && prev; state.Previous = power; boolVars[e.Address] = result;
    }

    private void ProcessLatch(LadderElement e)
    {
        bool set = EvaluateBool(e.SetExpr), reset = EvaluateBool(e.ResetExpr);
        bool current = TryGetBool(e.Address, out var value) && value;
        bool next = e.LatchType.Equals("SR", StringComparison.OrdinalIgnoreCase) ? (set ? true : reset ? false : current) : (reset ? false : set ? true : current);
        boolVars[e.Address] = next;
    }

    private bool EvaluateRungCondition(LadderRung rung) => rung.Branches.Count == 0 || rung.Branches.Any(EvaluateBranch);
    private bool EvaluateBranch(List<LadderElement> branch) => branch.All(EvaluateElement);
    private bool EvaluateElement(LadderElement e)
    {
        if (!e.Type.Equals("contact", StringComparison.OrdinalIgnoreCase)) return true;
        if (e.ContactType.Equals("comparison", StringComparison.OrdinalIgnoreCase)) return EvaluateComparison(e.Op, e.Left, e.Right);
        return e.ContactType.Equals("NC", StringComparison.OrdinalIgnoreCase) ? !EvaluateBool(e.Address) : EvaluateBool(e.Address);
    }

    private bool EvaluateComparison(string op, string left, string right)
    {
        double l = EvaluateNumeric(left), r = EvaluateNumeric(right);
        return op switch { "eq" => Math.Abs(l-r) < 1e-9, "ne" => Math.Abs(l-r) >= 1e-9, "gt" => l>r, "lt" => l<r, "ge" => l>=r, "le" => l<=r, _ => false };
    }

    private bool EvaluateBool(string expr)
    {
        expr = expr.Trim();
        if (expr.Equals("TRUE", StringComparison.OrdinalIgnoreCase)) return true;
        if (expr.Equals("FALSE", StringComparison.OrdinalIgnoreCase)) return false;
        if (double.TryParse(expr, NumberStyles.Float, CultureInfo.InvariantCulture, out var n)) return Math.Abs(n) > 1e-12;
        if (boolVars.TryGetValue(expr, out var b)) return b;
        if (forcedBool.TryGetValue(expr, out b)) return b;
        return new ExpressionEvaluator(this).Evaluate(expr) != 0;
    }

    private double EvaluateNumeric(string expr)
    {
        expr = expr.Trim();
        if (expr.StartsWith("T#", StringComparison.OrdinalIgnoreCase)) return ParseTimeLiteral(expr);
        if (double.TryParse(expr, NumberStyles.Float, CultureInfo.InvariantCulture, out var n)) return n;
        if (forcedNum.TryGetValue(expr, out n)) return n;
        if (numVars.TryGetValue(expr, out n)) return n;
        if (boolVars.TryGetValue(expr, out var b)) return b ? 1 : 0;
        return new ExpressionEvaluator(this).Evaluate(expr);
    }

    public static double ParseTimeLiteral(string text)
    {
        if (!text.StartsWith("T#", StringComparison.OrdinalIgnoreCase)) return 0;
        string body = text[2..].Replace("_", "", StringComparison.OrdinalIgnoreCase);
        var matches = Regex.Matches(body, @"(?<v>\d+(?:\.\d+)?)(?<u>ms|us|d|h|m|s)", RegexOptions.IgnoreCase);
        if (matches.Count == 0) return 0;
        double total = 0;
        foreach (Match m in matches)
        {
            double v = double.Parse(m.Groups["v"].Value, CultureInfo.InvariantCulture);
            total += m.Groups["u"].Value.ToLowerInvariant() switch { "us" => v / 1000, "ms" => v, "s" => v*1000, "m" => v*60000, "h" => v*3600000, "d" => v*86400000, _ => 0 };
        }
        return total;
    }

    private static string Describe(LadderRung r) => r.Coil is { } c ? $"coil {c.Address}" : r.Timer is { } t ? $"timer {t.Address}" : r.Counter is { } c ? $"counter {c.Address}" : r.Edge is { } e ? $"edge {e.EdgeType} {e.Address}" : r.Move is { } m ? $"move {m.Source}->{m.Dest}" : r.Jump is { } j ? $"{j.JumpType} {j.Label}" : r.Label is { } l ? $"label {l.Label}" : "logic";

    private static string AddressFor(IoMapping m, int index)
    {
        if (index == 0) return m.Address;
        int dot = m.Address.LastIndexOf('.');
        if (dot >= 0 && m.Type == "BOOL")
        {
            int bit = int.Parse(m.Address[(dot+1)..], CultureInfo.InvariantCulture) + index;
            int byteOffset = bit / 8; int newBit = bit % 8; string prefix = m.Address[..dot]; int p = prefix.Length-1; while(p>=0 && char.IsDigit(prefix[p])) p--; p++; int bytes = int.Parse(prefix[p..], CultureInfo.InvariantCulture); return prefix[..p] + (bytes+byteOffset) + "." + newBit;
        }
        int q=m.Address.Length-1; while(q>=0&&char.IsDigit(m.Address[q]))q--; q++; int baseNum=int.Parse(m.Address[q..],CultureInfo.InvariantCulture); int stride=m.Type switch{"INT"=>2,"DINT"or"REAL"or"TIME"=>4,_=>1}; return m.Address[..q]+(baseNum+index*stride);
    }

    public sealed record CounterInstanceView(int Count, int Preset);
    private sealed class TimerInstance { public string Type=""; public double DurationMs; public bool Input,PrevInput,Output; public double StartTime; }
    private sealed class CounterInstance { public string Type=""; public int Count,Preset; public bool Prev1,Prev2,Prev3,Prev4,Output; }
    private sealed class EdgeState { public bool Previous; }

    private sealed class ExpressionEvaluator
    {
        private readonly LadderSimulator owner; private string text=""; private int pos;
        public ExpressionEvaluator(LadderSimulator owner){this.owner=owner;}
        public double Evaluate(string expr){text=expr;pos=0;try{var v=ParseOr();Skip();return pos==text.Length?v:0;}catch{return 0;}}
        private void Skip(){while(pos<text.Length&&char.IsWhiteSpace(text[pos]))pos++;}
        private bool Match(string s){Skip();if(text.AsSpan(pos).StartsWith(s.AsSpan(),StringComparison.Ordinal)){pos+=s.Length;return true;}return false;}
        private double ParseOr(){double v=ParseAnd();while(Match("or")||Match("||"))v=(v!=0||ParseAnd()!=0)?1:0;return v;}
        private double ParseAnd(){double v=ParseCompare();while(Match("and")||Match("&&"))v=(v!=0&&ParseCompare()!=0)?1:0;return v;}
        private double ParseCompare(){double l=ParseAdd();foreach(var op in new[]{"==","!=","<=",">=","<",">"}){if(Match(op)){double r=ParseAdd();l=op switch{"=="=>Math.Abs(l-r)<1e-9?1:0,"!="=>Math.Abs(l-r)>=1e-9?1:0,"<="=>l<=r?1:0,">="=>l>=r?1:0,"<"=>l<r?1:0,">"=>l>r?1:0,_=>0};break;}}return l;}
        private double ParseAdd(){double v=ParseMul();while(true){if(Match("+"))v+=ParseMul();else if(Match("-"))v-=ParseMul();else if(Match("|"))v=(long)v|(long)ParseMul();else if(Match("^"))v=(long)v^(long)ParseMul();else break;}return v;}
        private double ParseMul(){double v=ParseUnary();while(true){if(Match("*"))v*=ParseUnary();else if(Match("//")){double r=ParseUnary();v=r==0?0:Math.Truncate(v/r);}else if(Match("/")){double r=ParseUnary();v=r==0?0:v/r;}else if(Match("%")){double r=ParseUnary();v=r==0?0:v%r;}else if(Match("&"))v=(long)v&(long)ParseUnary();else break;}return v;}
        private double ParseUnary(){if(Match("!")){return ParseUnary()==0?1:0;}if(Match("not")){return ParseUnary()==0?1:0;}if(Match("+"))return ParseUnary();if(Match("-"))return -ParseUnary();if(Match("~"))return ~(long)ParseUnary();return ParsePrimary();}
        private double ParsePrimary(){Skip();if(Match("(")){double v=ParseOr();Match(")");return v;}int start=pos;while(pos<text.Length&&(char.IsLetterOrDigit(text[pos])||text[pos]=='_'||text[pos]=='.'||text[pos]=='['||text[pos]==']'))pos++;string token=text[start..pos];if(token.Length==0)return 0;if(token.Equals("TRUE",StringComparison.OrdinalIgnoreCase))return 1;if(token.Equals("FALSE",StringComparison.OrdinalIgnoreCase))return 0;if(double.TryParse(token,NumberStyles.Float,CultureInfo.InvariantCulture,out var n))return n;if(owner.numVars.TryGetValue(token,out n))return n;if(owner.boolVars.TryGetValue(token,out var b))return b?1:0;if(owner.forcedNum.TryGetValue(token,out n))return n;if(owner.forcedBool.TryGetValue(token,out b))return b?1:0;return 0;}
    }
}
