using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace QPLCVisualSimulator
{
    public partial class LadderView : UserControl
    {
        private const double RailLeftX = 30;
        private const double RailRightX = 850;
        private const double ElementWidth = 60;
        private const double RungHeight = 60;
        private const double ContactWidth = 10;
        private const double ContactHeight = 40;

        private List<LadderNetwork> networks = new();
        private LadderSimulator simulator = null!;

        public LadderView()
        {
            InitializeComponent();
        }

        public void SetSimulator(LadderSimulator sim)
        {
            simulator = sim;
        }

        public void DrawNetworks(List<LadderNetwork> nets)
        {
            networks = nets;
            LadderCanvas.Children.Clear();

            double y = 20;
            foreach (var network in networks)
            {
                var title = new TextBlock
                {
                    Text = network.Name,
                    FontWeight = FontWeights.Bold,
                    FontSize = 12,
                    Foreground = Brushes.DarkSlateBlue
                };
                Canvas.SetLeft(title, RailLeftX);
                Canvas.SetTop(title, y);
                LadderCanvas.Children.Add(title);
                y += 25;

                foreach (var rung in network.Rungs)
                {
                    DrawRung(rung, y);
                    y += RungHeight + 20;
                }
                y += 15;
            }
        }

        // ---------------------- Helper evaluation ----------------------
        private bool IsContactConducting(LadderElement elem)
        {
            if (simulator == null) return false;

            if (elem.Type == "contact")
            {
                if (elem.ContactType == "comparison")
                    return EvaluateComparison(elem);
                else
                {
                    var bools = simulator.GetBoolVariables();
                    bool state = bools.TryGetValue(elem.Address, out bool val) && val;
                    return elem.ContactType == "NO" ? state : !state;
                }
            }
            return false;
        }

        private bool EvaluateComparison(LadderElement elem)
        {
            double l = GetNumericValue(elem.Left);
            double r = GetNumericValue(elem.Right);
            return elem.Op switch
            {
                "eq" => l == r,
                "ne" => l != r,
                "gt" => l > r,
                "lt" => l < r,
                "ge" => l >= r,
                "le" => l <= r,
                _ => false
            };
        }

        private double GetNumericValue(string expr)
        {
            if (double.TryParse(expr, out double literal)) return literal;
            var numVars = simulator.GetNumericVariables();
            if (numVars.TryGetValue(expr, out double val)) return val;
            var boolVars = simulator.GetBoolVariables();
            if (boolVars.TryGetValue(expr, out bool b)) return b ? 1.0 : 0.0;
            return 0.0;
        }

        private bool IsBranchTrue(List<LadderElement> branch)
        {
            foreach (var elem in branch)
            {
                if (!IsContactConducting(elem))
                    return false;
            }
            return true;
        }

        private Brush ActiveBrush => Brushes.Green;
        private Brush InactiveBrush => Brushes.Gray;

        // ---------------------- Drawing methods ----------------------
        private void DrawRung(LadderRung rung, double y)
        {
            // Rails
            DrawRail(RailLeftX, y, RungHeight);
            DrawRail(RailRightX, y, RungHeight);

            double centerY = y + RungHeight / 2;
            double startX = RailLeftX + 20;
            double outputLeft;

            // Determine output element position and calculate left edge
            if (rung.Coil != null)
            {
                outputLeft = RailRightX - 80;
            }
            else if (rung.Timer != null)
            {
                outputLeft = RailRightX - 120;
            }
            else if (rung.Counter != null)
            {
                outputLeft = RailRightX - 140;
            }
            else
            {
                outputLeft = RailRightX - 40; // default
            }

            // Compute branch states
            var branchStates = rung.Branches.Select(b => IsBranchTrue(b)).ToList();
            bool rungTrue = branchStates.Any(b => b);

            // Draw connection from left rail to start of branches
            DrawHorizontalLine(RailLeftX, centerY, startX, centerY, rungTrue);

            // Draw series/parallel paths up to outputLeft
            DrawBranches(rung, startX, centerY, branchStates, rungTrue, outputLeft);

            // Draw output element
            if (rung.Coil != null)
                DrawCoil(rung.Coil, outputLeft, centerY, rungTrue);
            else if (rung.Timer != null)
                DrawTimer(rung.Timer, outputLeft, centerY, rungTrue);
            else if (rung.Counter != null)
                DrawCounter(rung.Counter, outputLeft, centerY, rungTrue);

            // Draw connection from output element to right rail
            double outputRight = outputLeft + GetOutputElementWidth(rung);
            DrawHorizontalLine(outputRight, centerY, RailRightX, centerY, rungTrue);
        }

        private double GetOutputElementWidth(LadderRung rung)
        {
            if (rung.Coil != null) return 50;
            if (rung.Timer != null) return 90;
            if (rung.Counter != null) return 100;
            return 40;
        }

        private void DrawRail(double x, double y, double height)
        {
            var rail = new Line
            {
                X1 = x, Y1 = y,
                X2 = x, Y2 = y + height,
                Stroke = Brushes.Black,
                StrokeThickness = 4
            };
            LadderCanvas.Children.Add(rail);
        }

        private void DrawBranches(LadderRung rung, double startX, double centerY,
            List<bool> branchStates, bool rungTrue, double outputLeft)
        {
            if (rung.Branches.Count == 0)
            {
                DrawHorizontalLine(startX, centerY, outputLeft, centerY, rungTrue);
                return;
            }

            if (rung.Branches.Count == 1)
            {
                // Simple series
                var branch = rung.Branches[0];
                bool branchTrue = branchStates[0];
                double x = startX;

                // Horizontal to first element
                DrawHorizontalLine(x, centerY, x + 10, centerY, branchTrue);
                x += 10;

                for (int i = 0; i < branch.Count; i++)
                {
                    DrawElement(branch[i], x, centerY - ContactHeight / 2, branchTrue);
                    x += ElementWidth;
                    DrawHorizontalLine(x, centerY, x + 10, centerY, branchTrue);
                    x += 10;
                }

                // Horizontal to output element
                DrawHorizontalLine(x, centerY, outputLeft, centerY, branchTrue);
            }
            else
            {
                // Parallel branches (OR)
                double branchSpacing = RungHeight / (rung.Branches.Count + 1);
                List<double> branchYs = new();
                for (int i = 0; i < rung.Branches.Count; i++)
                    branchYs.Add(centerY - RungHeight/2 + (i + 1) * branchSpacing);

                double commonStartX = startX;
                double commonEndX = startX + ElementWidth * rung.Branches.Max(b => b.Count) + 20;

                // Vertical from left rail to first branch and between branches
                DrawVerticalLine(commonStartX, branchYs[0], centerY, rungTrue);
                DrawVerticalLine(commonStartX, branchYs[^1], centerY, rungTrue);
                DrawVerticalLine(commonEndX, branchYs[0], centerY, rungTrue);
                DrawVerticalLine(commonEndX, branchYs[^1], centerY, rungTrue);

                // Draw each branch
                for (int i = 0; i < rung.Branches.Count; i++)
                {
                    double by = branchYs[i];
                    bool branchTrue = branchStates[i];
                    double x = commonStartX;

                    DrawHorizontalLine(x, by, x + 10, by, branchTrue);
                    x += 10;

                    for (int j = 0; j < rung.Branches[i].Count; j++)
                    {
                        DrawElement(rung.Branches[i][j], x, by - ContactHeight / 2, branchTrue);
                        x += ElementWidth;
                        DrawHorizontalLine(x, by, x + 10, by, branchTrue);
                        x += 10;
                    }

                    // Vertical connection from branch end to common end
                    DrawVerticalLine(x, by, centerY, branchTrue);
                }

                // Common horizontal to output element
                DrawHorizontalLine(commonEndX, centerY, outputLeft, centerY, rungTrue);
            }
        }

        private void DrawElement(LadderElement elem, double x, double y, bool conducting)
        {
            if (elem.Type == "contact")
                DrawContact(elem, x, y, conducting);
            else if (elem.Type == "comparison")
                DrawComparison(elem, x, y, conducting);
        }

        private void DrawContact(LadderElement elem, double x, double y, bool conducting)
        {
            Brush brush = conducting ? ActiveBrush : InactiveBrush;

            var line1 = new Line { X1 = x, Y1 = y, X2 = x, Y2 = y + ContactHeight, Stroke = brush, StrokeThickness = 2 };
            var line2 = new Line { X1 = x + ContactWidth, Y1 = y, X2 = x + ContactWidth, Y2 = y + ContactHeight, Stroke = brush, StrokeThickness = 2 };
            LadderCanvas.Children.Add(line1);
            LadderCanvas.Children.Add(line2);

            if (elem.ContactType == "NC")
            {
                var slash = new Line { X1 = x, Y1 = y + ContactHeight, X2 = x + ContactWidth, Y2 = y, Stroke = brush, StrokeThickness = 1.5 };
                LadderCanvas.Children.Add(slash);
            }

            var label = new TextBlock { Text = elem.Address, FontSize = 10, Foreground = Brushes.Blue };
            Canvas.SetLeft(label, x - 5);
            Canvas.SetTop(label, y + ContactHeight + 2);
            LadderCanvas.Children.Add(label);

            var clickArea = new Rectangle
            {
                Width = ContactWidth + 4,
                Height = ContactHeight + 4,
                Fill = Brushes.Transparent,
                Tag = elem
            };
            clickArea.MouseLeftButtonDown += (s, e) =>
            {
                if (simulator != null)
                {
                    var varName = elem.Address;
                    var bools = simulator.GetBoolVariables();
                    if (bools.ContainsKey(varName))
                    {
                        bool newVal = !bools[varName];
                        simulator.SetBool(varName, newVal);
                        DrawNetworks(networks);
                    }
                }
            };
            Canvas.SetLeft(clickArea, x - 2);
            Canvas.SetTop(clickArea, y - 2);
            LadderCanvas.Children.Add(clickArea);
        }

        private void DrawComparison(LadderElement elem, double x, double y, bool conducting)
        {
            Brush brush = conducting ? ActiveBrush : InactiveBrush;
            var box = new Rectangle { Width = 50, Height = 30, Fill = Brushes.White, Stroke = brush, StrokeThickness = 2 };
            Canvas.SetLeft(box, x);
            Canvas.SetTop(box, y + 5);
            LadderCanvas.Children.Add(box);

            var text = new TextBlock { Text = $"{elem.Left} {elem.Op} {elem.Right}", FontSize = 10, Foreground = Brushes.DarkGreen };
            Canvas.SetLeft(text, x + 2);
            Canvas.SetTop(text, y + 8);
            LadderCanvas.Children.Add(text);
        }

        private void DrawCoil(LadderElement elem, double x, double centerY, bool rungTrue)
        {
            bool output = simulator != null && simulator.GetBoolVariables().TryGetValue(elem.Address, out bool val) && val;
            Brush brush = output ? ActiveBrush : InactiveBrush;

            string symbol = elem.ContactType == "reset" ? "(R)" : elem.ContactType == "set" ? "(S)" : "( )";
            var coilText = new TextBlock
            {
                Text = $"{symbol} {elem.Address}",
                FontWeight = FontWeights.Bold,
                FontSize = 12,
                Foreground = brush
            };
            Canvas.SetLeft(coilText, x);
            Canvas.SetTop(coilText, centerY - 10);
            LadderCanvas.Children.Add(coilText);
        }

        private void DrawTimer(LadderElement elem, double x, double centerY, bool rungTrue)
        {
            bool output = simulator != null && simulator.GetBoolVariables().TryGetValue(elem.Address, out bool val) && val;
            Brush brush = output ? ActiveBrush : InactiveBrush;

            var boxWidth = 90;
            var boxHeight = 60;
            var boxY = centerY - boxHeight / 2;
            var box = new Rectangle { Width = boxWidth, Height = boxHeight, Fill = Brushes.LightYellow, Stroke = brush, StrokeThickness = 2 };
            Canvas.SetLeft(box, x);
            Canvas.SetTop(box, boxY);
            LadderCanvas.Children.Add(box);

            var title = new TextBlock { Text = elem.ContactType, FontWeight = FontWeights.Bold, FontSize = 11 };
            Canvas.SetLeft(title, x + 15);
            Canvas.SetTop(title, boxY + 20);
            LadderCanvas.Children.Add(title);

            DrawPin(x, boxY + boxHeight / 2, "IN", elem.Address, brush);
            DrawPin(x + boxWidth, boxY + boxHeight / 2, "Q", elem.Address, brush);
            DrawPin(x + boxWidth / 2, boxY, "PT", elem.Source, brush);
            DrawPin(x + boxWidth / 2, boxY + boxHeight, "ET", "", brush);
        }

        private void DrawCounter(LadderElement elem, double x, double centerY, bool rungTrue)
        {
            bool output = simulator != null && simulator.GetBoolVariables().TryGetValue(elem.Address, out bool val) && val;
            Brush brush = output ? ActiveBrush : InactiveBrush;

            var boxWidth = 100;
            var boxHeight = 80;
            var boxY = centerY - boxHeight / 2;
            var box = new Rectangle { Width = boxWidth, Height = boxHeight, Fill = Brushes.LightCyan, Stroke = brush, StrokeThickness = 2 };
            Canvas.SetLeft(box, x);
            Canvas.SetTop(box, boxY);
            LadderCanvas.Children.Add(box);

            var title = new TextBlock { Text = elem.ContactType, FontWeight = FontWeights.Bold, FontSize = 11 };
            Canvas.SetLeft(title, x + 15);
            Canvas.SetTop(title, boxY + 30);
            LadderCanvas.Children.Add(title);

            if (elem.ContactType == "count_up")
            {
                DrawPin(x, boxY + 20, "CU", elem.Input1, brush);
                DrawPin(x, boxY + 60, "R", elem.Input2, brush);
                DrawPin(x + boxWidth, boxY + 40, "Q", elem.Address, brush);
                DrawPin(x + boxWidth / 2, boxY + boxHeight, "PV", elem.Preset, brush);
            }
            else if (elem.ContactType == "count_down")
            {
                DrawPin(x, boxY + 20, "CD", elem.Input1, brush);
                DrawPin(x, boxY + 60, "LD", elem.Input2, brush);
                DrawPin(x + boxWidth, boxY + 40, "Q", elem.Address, brush);
                DrawPin(x + boxWidth / 2, boxY + boxHeight, "PV", elem.Preset, brush);
            }
            else if (elem.ContactType == "count_updown")
            {
                DrawPin(x, boxY + 10, "CU", elem.Input1, brush);
                DrawPin(x, boxY + 30, "CD", elem.Input2, brush);
                DrawPin(x, boxY + 50, "R", elem.Input3, brush);
                DrawPin(x, boxY + 70, "LD", elem.Input4, brush);
                DrawPin(x + boxWidth, boxY + 20, "QU", elem.Address, brush);
                DrawPin(x + boxWidth, boxY + 60, "QD", elem.Address, brush);
                DrawPin(x + boxWidth / 2, boxY + boxHeight, "PV", elem.Preset, brush);
            }
        }

        private void DrawPin(double x, double y, string pinName, string value, Brush brush)
        {
            var pinText = new TextBlock { Text = $"{pinName}: {value}", FontSize = 9, Foreground = brush };
            Canvas.SetLeft(pinText, x + 2);
            Canvas.SetTop(pinText, y);
            LadderCanvas.Children.Add(pinText);
        }

        // Helper drawing primitives
        private void DrawHorizontalLine(double x1, double y1, double x2, double y2, bool active)
        {
            var line = new Line
            {
                X1 = x1,
                Y1 = y1,
                X2 = x2,
                Y2 = y2,
                Stroke = active ? ActiveBrush : InactiveBrush,
                StrokeThickness = 2
            };
            LadderCanvas.Children.Add(line);
        }

        private void DrawVerticalLine(double x, double y1, double y2, bool active)
        {
            var line = new Line
            {
                X1 = x,
                Y1 = y1,
                X2 = x,
                Y2 = y2,
                Stroke = active ? ActiveBrush : InactiveBrush,
                StrokeThickness = 2
            };
            LadderCanvas.Children.Add(line);
        }
    }
}